/**
 * Mercury Document Hub - Code.gs (server) v2: eight workstream tabs
 * Each workstream (CTO, MDM, ...) is its own tab with the same headers. The app reads all of them,
 * writes each document back to its own tab, and applies per-workstream editing rights.
 * Execute as owner; access = purestorage.com domain. Columns are read BY HEADER NAME.
 */
var SS_ID = '1egbINWnEhgR5COU88FKDeFTfzmJDGLLUOOCWcVdTHVw';
var DOMAIN = 'purestorage.com';
var OWNER_SEED = 'sngouv@purestorage.com';
var TAB = { HOME: 'HOME', TEAM: 'Team', ACCESS: 'Access', REQ: 'Access_Requests', LOG: 'Audit_Log',
            ARCHIVE: 'Archive', CONFIG: 'Config', SPEC: 'Project_Spec', SHADOW: '_Shadow', FOLDERS: '_Folders' };
/** Tabs that are not workstreams (compared in lower case). */
var SYSTEM_TABS = ['home', 'team', 'access', 'access_requests', 'audit_log', 'archive', 'config', 'project_spec', '_shadow', '_folders'];
var RANK = { none: 0, viewer: 1, editor: 2, admin: 3, owner: 4 };
var ROLE_LIST = ['viewer', 'editor', 'admin', 'owner'];
var ASSIGN = 'Assigned To';   // column that exists only in the shared area tab
var SYS = { ID: 'Doc ID', TYPE: 'Doc Type', ADDED: 'Date Added', MOD: 'Last Modified', BY: 'Modified By', STATUS: 'Status', ADDED_BY: 'Added By' };
var CFG_DEFAULTS = { APP_TITLE: 'Mercury Document Hub', POLL_SECONDS: '30', HEADER_ROW: '', HIDDEN_COLUMNS: '',
                     GROUP_A: 'Doc Type', GROUP_B: 'L_1', SHELF_BY: 'L_1', PAGE_SIZE: '15', SOON_DAYS: '2', PROGRAM_NAME: 'Mercury SCM and finance',
                     SHELF_ORDER: '', AUTO_VIEWER: '', WORKSTREAMS: '', SHARED_TAB: 'All Workstream Assignment', SHARED_HINT: 'All Workstream',
                     NEXT_VISIT_FORMULA: 'IF(AND({latest}{row}<>"",{window}{row}<>""),{latest}{row}+{window}{row},"")',
                     WEEKDAY_FORMULA: 'IF({next}{row}="","",TEXT({next}{row},"ddd"))' };
/** Earlier default app names. If the Config tab still holds one of these, the app shows the current default name instead.
 *  A custom title chosen by the owner is never touched. */
var OLD_APP_NAMES = ['Document Hub', 'Mercury Document Central', 'Gabby-Sunlong Document Central'];
var _ss = null, _cfg = null, _acc = null, _wsn = null;

/* ---------- basics ---------- */

function ss_() { return _ss || (_ss = SpreadsheetApp.openById(SS_ID)); }

function sh_(n) {
  var s = ss_().getSheetByName(n);
  if (!s) throw new Error('Missing tab "' + n + '". Run setupAll() from the Mercury Document Hub menu in the sheet.');
  return s;
}

function tz_() { return ss_().getSpreadsheetTimeZone(); }

function me_() { return String(Session.getActiveUser().getEmail() || '').toLowerCase(); }

function iso_(d) { return Utilities.formatDate(d, tz_(), 'yyyy-MM-dd'); }

function stamp_(d) { return Utilities.formatDate(d, tz_(), 'yyyy-MM-dd HH:mm:ss'); }

function parseDate_(s) {
  if (s instanceof Date) return s;
  var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(s || ''));
  if (m) return new Date(+m[1], +m[2] - 1, +m[3], 12, 0, 0);
  var d = new Date(s); return isNaN(d.getTime()) ? '' : d;
}

function today_() { return parseDate_(iso_(new Date())); }

function isDomain_(email) { return !!email && email.slice(-(DOMAIN.length + 1)) === '@' + DOMAIN; }

function clip_(v) { v = (v === null || v === undefined) ? '' : String(v); return v.length > 400 ? v.slice(0, 400) + '...' : v; }

function bump_() {
  // Strictly increasing, so two changes in the same millisecond can never share a token.
  var prev = 0; try { prev = Number(tokenNow_()) || 0; } catch (e) {}
  var v = String(Math.max(Date.now(), prev + 1));
  PropertiesService.getScriptProperties().setProperty('SYNC', v);
  try { CacheService.getScriptCache().put('sync', v, 21600); } catch (e) {}
}

/** Change token. Read from the cache (fast); falls back to script properties. No Drive call. */
function tokenNow_() {
  var cache = CacheService.getScriptCache(), v = null;
  try { v = cache.get('sync'); } catch (e) {}
  if (v === null || v === undefined) {
    v = PropertiesService.getScriptProperties().getProperty('SYNC') || '0';
    try { cache.put('sync', v, 21600); } catch (e) {}
  }
  return v;
}

/** Fast 53-bit string hash (pure JS; replaces one MD5 service call per row). */
function hash53_(str) {
  var h1 = 0xdeadbeef, h2 = 0x41c6ce57, ch;
  for (var i = 0; i < str.length; i++) {
    ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

function withLock_(fn) {
  var lock = LockService.getScriptLock(); lock.waitLock(25000);
  try { return fn(); } finally { lock.releaseLock(); }
}


/* ---------- config ---------- */

function cfg_() {
  if (_cfg) return _cfg;
  var cache = CacheService.getScriptCache();
  try { var raw = cache.get('cfg'); if (raw) { _cfg = JSON.parse(raw); return _cfg; } } catch (e) {}
  var c = {}; for (var k in CFG_DEFAULTS) c[k] = CFG_DEFAULTS[k];
  var s = ss_().getSheetByName(TAB.CONFIG);
  if (s && s.getLastRow() > 1) {
    s.getRange(2, 1, s.getLastRow() - 1, 2).getValues().forEach(function (r) {
      if (String(r[0]).trim() !== '' && String(r[1]) !== '') c[String(r[0]).trim()] = String(r[1]);
    });
  }
  if (OLD_APP_NAMES.indexOf(String(c.APP_TITLE).trim()) >= 0) c.APP_TITLE = CFG_DEFAULTS.APP_TITLE;
  _cfg = c; try { cache.put('cfg', JSON.stringify(c), 300); } catch (e) {}
  return c;
}
/** Forgets the cached Config (after the Config tab changes). */
function cfgDirty_() { _cfg = null; try { CacheService.getScriptCache().remove('cfg'); } catch (e) {} }
function sheetUrl_() { return 'https://docs.google.com/spreadsheets/d/' + SS_ID + '/edit'; }

function pubConfig_() {
  var c = cfg_();
  return { APP_TITLE: c.APP_TITLE, POLL_SECONDS: c.POLL_SECONDS, PAGE_SIZE: c.PAGE_SIZE, SOON_DAYS: c.SOON_DAYS,
           GROUP_A: c.GROUP_A, GROUP_B: c.GROUP_B, SHELF_BY: c.SHELF_BY, SHELF_ORDER: c.SHELF_ORDER, PROGRAM_NAME: c.PROGRAM_NAME, SHARED_HINT: c.SHARED_HINT };
}


/* ---------- web app entry ---------- */

function doGet() {
  var t = HtmlService.createTemplateFromFile('Index'), boot;
  try { boot = JSON.stringify(startup_()); } catch (e) { boot = JSON.stringify({ error: String((e && e.message) || e) }); }
  // The first screen's data rides along with the page, saving a full server round trip on load.
  t.boot = boot.replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return t.evaluate()
    .setTitle(cfg_().APP_TITLE)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


/* ---------- cell helpers ---------- */

function fromCell_(v) {
  if (v instanceof Date) return isNaN(v.getTime()) ? '' : iso_(v);
  if (v === null || v === undefined) return '';
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  return v;
}

function toCell_(type, v) {
  if (v === null || v === undefined || v === '') return '';
  if (type === 'date') return parseDate_(v) || '';
  if (type === 'number') { var n = Number(v); return isNaN(n) ? '' : n; }
  return String(v).trim();
}

function detectType_(url) {
  var u = String(url || '').toLowerCase();
  if (!u) return '';
  if (u.indexOf('docs.google.com/spreadsheets') >= 0) return 'Sheet';
  if (u.indexOf('docs.google.com/presentation') >= 0) return 'Slides';
  if (u.indexOf('docs.google.com/document') >= 0) return 'Doc';
  if (u.indexOf('docs.google.com/forms') >= 0 || u.indexOf('forms.gle') >= 0) return 'Form';
  if (u.indexOf('drive.google.com/drive/folders') >= 0) return 'Folder';
  if (u.indexOf('drive.google.com') >= 0) return 'File';
  if (u.indexOf('script.google.com') >= 0) return 'App Script';
  if (u.indexOf('mail.google.com') >= 0) return 'Email';
  if (u.indexOf('asana.com') >= 0) return 'Asana';
  if (u.indexOf('wiki.') >= 0 || u.indexOf('confluence') >= 0 || u.indexOf('atlassian.net') >= 0) return 'Wiki';
  if (u.indexOf('hub.purestorage') >= 0) return 'Hub page';
  if (u.indexOf('youtube.com') >= 0 || u.indexOf('youtu.be') >= 0 || u.indexOf('loom.com') >= 0) return 'Video';
  if (/\.pdf(\?|#|$)/.test(u)) return 'PDF';
  return 'Link';
}

/** Canonical form of a link for duplicate detection. Drops tracking parameters, a trailing slash,
 *  the protocol and a gid-only fragment (so ?gid=1 and #gid=1 match); keeps other fragments (e.g. Gmail threads, slides). */
function normUrl_(u) {
  u = String(u || '').trim(); if (!u) return '';
  var m = /^(https?:)\/\/([^\/?#]+)([^?#]*)(\?[^#]*)?(#.*)?$/i.exec(u);
  if (!m) return u.toLowerCase();
  var host = m[2].toLowerCase(), path = m[3].replace(/\/+$/, ''), q = (m[4] || '').replace(/^\?/, ''), frag = (m[5] || '').replace(/^#/, '');
  var params = [];
  q.split('&').forEach(function (p) {
    if (!p) return;
    var k = p.split('=')[0].toLowerCase();
    if (/^(usp|ouid|rtpof|sd|authuser|hl|resourcekey|utm_[a-z]+)$/.test(k)) return;
    params.push(p);
  });
  var g = /^gid=(\d+)$/.exec(frag);
  if (g) { if (!params.some(function (p) { return /^gid=/.test(p); })) params.push('gid=' + g[1]); frag = ''; }
  params.sort();
  return host + path + (params.length ? '?' + params.join('&') : '') + (frag ? '#' + frag : '');
}

function colLetter_(idx) {
  var s = ''; idx++;
  while (idx > 0) { var m = (idx - 1) % 26; s = String.fromCharCode(65 + m) + s; idx = Math.floor((idx - 1) / 26); }
  return s;
}

/** Builds a formula for a row from a Config template ({row}, {latest}, {window}, {next} are replaced). */
function formulaText_(key, headers, rl, rowNum) {
  var tpl = String(cfg_()[key] || '').trim(); if (!tpl) return '';
  var L = function (n) { var i = n ? headers.indexOf(n) : -1; return i >= 0 ? colLetter_(i) : ''; };
  var lt = L(rl.latest), wd = L(rl.window), nx = L(rl.next);
  if ((/\{latest\}/.test(tpl) && !lt) || (/\{window\}/.test(tpl) && !wd) || (/\{next\}/.test(tpl) && !nx)) return '';
  return '=' + tpl.replace(/^=/, '').replace(/\{row\}/g, rowNum).replace(/\{latest\}/g, lt).replace(/\{window\}/g, wd).replace(/\{next\}/g, nx);
}

function formulaKey_(sc, c) { return c.name === sc.roles.next ? 'NEXT_VISIT_FORMULA' : (/weekday/i.test(c.name) ? 'WEEKDAY_FORMULA' : ''); }

function formulaFor_(sc, h, c, rowNum) { var k = formulaKey_(sc, c); return k ? formulaText_(k, h.headers, sc.roles, rowNum) : ''; }

function fmtId_(n) { return 'DOC-' + ('0000' + n).slice(-4); }

/* ---------- workstreams: one tab each ---------- */
function looksLikeWs_(s) {
  var lr = Math.min(15, s.getLastRow()), lc = Math.min(30, s.getLastColumn());
  if (lr < 1 || lc < 1) return false;
  var v = s.getRange(1, 1, lr, lc).getValues(), url = false, title = false;
  for (var i = 0; i < v.length; i++) for (var j = 0; j < v[i].length; j++) {
    var x = String(v[i][j]).trim().toLowerCase();
    if (x === 'url') url = true; else if (x === 'title') title = true;
  }
  return url && title;
}
/** Names of the workstream tabs, in sheet order (or the order in Config WORKSTREAMS). Cached for 10 minutes. */
function wsNames_() {
  if (_wsn) return _wsn;
  var cache = CacheService.getScriptCache();
  try { var raw = cache.get('wsn'); if (raw) { _wsn = JSON.parse(raw); return _wsn; } } catch (e) {}
  var over = String(cfg_().WORKSTREAMS || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean), found = [];
  ss_().getSheets().forEach(function (s) {
    var n = s.getName();
    if (SYSTEM_TABS.indexOf(n.toLowerCase()) >= 0) return;
    if (over.length ? over.indexOf(n) >= 0 : looksLikeWs_(s)) found.push(n);
  });
  if (over.length) found = over.filter(function (n) { return found.indexOf(n) >= 0; });
  try { cache.put('wsn', JSON.stringify(found), 600); } catch (e) {}
  _wsn = found; return found;
}
/** The shared area ("All Workstream Assignment"): documents stored once and assigned to all or some workstreams. '' when the tab does not exist. */
function sharedName_() {
  var n = String(cfg_().SHARED_TAB || '').trim();
  if (/^(off|none|no)$/i.test(n)) return '';   // type off in Config to turn the shared area off
  return n && wsNames_().indexOf(n) >= 0 ? n : '';
}
/** Assigned To: 'All' or a semicolon list of workstream names, checked against the real workstreams. */
function normAssign_(raw) {
  var shared = sharedName_(), names = wsNames_().filter(function (n) { return n !== shared; });
  var parts = String(raw === undefined || raw === null ? '' : raw).split(/[;,\n]+/).map(function (x) { return x.trim(); }).filter(Boolean);
  if (!parts.length || parts.some(function (p) { return /^(all|\*)$/i.test(p); })) return 'All';
  var out = [];
  parts.forEach(function (p) {
    var m = names.filter(function (n) { return n.toLowerCase() === p.toLowerCase(); })[0];
    if (!m) throw new Error('"' + p + '" is not a workstream. Use All, or names of workstreams separated by semicolons.');
    if (out.indexOf(m) < 0) out.push(m);
  });
  if (out.length >= names.length) return 'All';
  return names.filter(function (n) { return out.indexOf(n) >= 0; }).join('; ');
}
/** Applies the assignment rules to the values being saved: only the shared area keeps Assigned To. */
function prepAssign_(ws, sc, v, isNew) {
  var ac = colByName_(sc, ASSIGN); if (!ac) return v;
  var out = {}; for (var k in v) out[k] = v[k];
  if (ws === sharedName_()) { if (isNew || ASSIGN in out) out[ASSIGN] = normAssign_(out[ASSIGN]); }
  else delete out[ASSIGN];
  return out;
}
function wsDirty_() { _wsn = null; try { CacheService.getScriptCache().remove('wsn'); } catch (e) {} }

/** Which columns of a tab hold formulas. Cached per tab so normal loads never read formulas. */
function formulaColsFor_(h, forms) {
  var cache = CacheService.getScriptCache(), key = 'fc:' + h.ws;
  try { var raw = cache.get(key); if (raw) return JSON.parse(raw); } catch (e) {}
  var all = forms || h.sheet.getDataRange().getFormulas().slice(h.hr), n = h.vals.length, out = [];
  h.headers.forEach(function (name, i) {
    if (!name) return;
    var fcount = 0, nonEmpty = 0;
    for (var k = 0; k < n; k++) {
      if (all[k] && all[k][i]) fcount++;
      var v = h.vals[k][i]; if (v !== '' && v !== null) nonEmpty++;
    }
    if (n > 0 && fcount >= 1 && fcount >= 0.5 * Math.max(1, nonEmpty)) out.push(name);
  });
  try { cache.put(key, JSON.stringify(out), 600); } catch (e) {}
  return out;
}
/** Reads one workstream tab. Writes need withForms=true; normal loads read values only (one call per tab). */
function readWs_(name, withForms) {
  var sheet = ss_().getSheetByName(name);
  if (!sheet) throw new Error('The workstream tab "' + name + '" was not found.');
  var dr = sheet.getDataRange(), all = dr.getValues();
  var hr = headerRowFrom_(all); if (hr > all.length) hr = 1;
  var headers = all[hr - 1].map(function (x) { return String(x).trim(); });
  var h = { sheet: sheet, ws: name, hr: hr, lc: headers.length, headers: headers, vals: all.slice(hr), forms: withForms ? dr.getFormulas().slice(hr) : [] };
  h.fcols = formulaColsFor_(h, withForms ? h.forms : null);
  return h;
}

function schema_(h) {
  var hidden = String(cfg_().HIDDEN_COLUMNS).split(',').map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
  var rl = roles_(h), n = h.vals.length, cols = [];
  var sysNames = [SYS.ID, SYS.TYPE, SYS.ADDED, SYS.MOD, SYS.BY, SYS.STATUS, SYS.ADDED_BY];
  h.headers.forEach(function (name, i) {
    if (!name) return;
    var vs = h.vals.map(function (r) { return r[i]; }).filter(function (v) { return v !== '' && v !== null; });
    var formula = !!(h.fcols && h.fcols.indexOf(name) >= 0);
    var tplKey = name === rl.next ? 'NEXT_VISIT_FORMULA' : (/weekday/i.test(name) ? 'WEEKDAY_FORMULA' : '');
    if (!formula && tplKey && String(cfg_()[tplKey] || '').trim()) formula = true;
    var type = inferType_(name, vs);
    var dist = {}; vs.forEach(function (v) { dist[String(fromCell_(v))] = 1; });
    var dc = Object.keys(dist).length;
    var excl = [rl.title, rl.url, rl.note, rl.id].indexOf(name) >= 0 || name === ASSIGN || /weekday|comment|description/i.test(name);
    var categorical = !excl && (type === 'text' || type === 'flag') && dc >= 1 && dc <= 60 && (dc <= 12 || dc <= n * 0.6);
    cols.push({ name: name, index: i, type: type, formula: formula,
                readonly: formula || name === SYS.ID || name === SYS.BY || name === SYS.TYPE || name === SYS.ADDED_BY,
                system: sysNames.indexOf(name) >= 0, categorical: categorical, hidden: hidden.indexOf(name.toLowerCase()) >= 0 });
  });
  return { cols: cols, roles: rl, headerRow: h.hr,
           titleIdx: rl.title ? h.headers.indexOf(rl.title) : -1, urlIdx: rl.url ? h.headers.indexOf(rl.url) : -1 };
}

/* ---------- document IDs (one sequence across all workstreams) ---------- */
function scanMaxId_() {
  var max = 0;
  function scan(v) { var m = /^DOC-(\d+)$/.exec(String(v)); if (m) max = Math.max(max, +m[1]); }
  wsNames_().forEach(function (n) {
    var h = readWs_(n, false), i = h.headers.indexOf(SYS.ID);
    if (i >= 0) h.vals.forEach(function (r) { scan(r[i]); });
  });
  var a = ss_().getSheetByName(TAB.ARCHIVE);
  if (a && a.getLastRow() > 1) a.getRange(2, 1, a.getLastRow() - 1, 1).getValues().forEach(function (r) { scan(r[0]); });
  return max;
}
/** Reserves `count` IDs and returns the first number. Call inside the script lock. */
function allocIds_(count) {
  var props = PropertiesService.getScriptProperties(), cur = props.getProperty('ID_SEQ');
  var seq = (cur === null || cur === undefined || cur === '') ? scanMaxId_() : Math.max(+cur, 0);
  props.setProperty('ID_SEQ', String(seq + count));
  return seq + 1;
}
/** Fills blank system fields on rows that have content in one workstream tab. Safe to re-run. */
function fillMissingWs_(name, by) {
  var h = readWs_(name, false), sc = schema_(h), rl = sc.roles, n = h.vals.length; if (!n) return 0;
  var ix = function (nm) { return nm ? h.headers.indexOf(nm) : -1; };
  var iT = ix(rl.title), iU = ix(rl.url), iId = ix(SYS.ID), iTy = ix(SYS.TYPE), iA = ix(SYS.ADDED), iM = ix(SYS.MOD), iB = ix(SYS.BY), iS = ix(SYS.STATUS);
  if (iId < 0) return 0;
  var need = 0;
  h.vals.forEach(function (r) { if (((iT >= 0 && r[iT] !== '') || (iU >= 0 && r[iU] !== '')) && (r[iId] === '' || r[iId] === null)) need++; });
  var next = need ? allocIds_(need) : 0, today = today_(), changed = 0, cols = {};
  [iId, iTy, iA, iM, iB, iS].forEach(function (i) { if (i >= 0) cols[i] = h.vals.map(function (r) { return [r[i]]; }); });
  h.vals.forEach(function (r, k) {
    var content = (iT >= 0 && r[iT] !== '') || (iU >= 0 && r[iU] !== '');
    if (!content) return;
    function setIf(i, val) { if (i >= 0 && val !== '' && (r[i] === '' || r[i] === null)) { cols[i][k][0] = val; changed++; } }
    if (r[iId] === '' || r[iId] === null) { cols[iId][k][0] = fmtId_(next++); changed++; }
    setIf(iTy, detectType_(iU >= 0 ? r[iU] : ''));
    setIf(iA, today); setIf(iM, today); setIf(iB, by || 'System'); setIf(iS, 'Active');
  });
  if (changed) {
    Object.keys(cols).forEach(function (i) { h.sheet.getRange(h.hr + 1, +i + 1, n, 1).setValues(cols[i]); });
    [iA, iM].forEach(function (i) { if (i >= 0) h.sheet.getRange(h.hr + 1, i + 1, n, 1).setNumberFormat('mm/dd/yyyy'); });
    bump_();
  }
  return changed;
}
/** If the same Doc ID appears in two workstream tabs (for example after copying a row), the later one gets a new ID. */
function dedupeIds_() {
  var seen = {}, logs = [], fixes = 0;
  wsNames_().forEach(function (n) {
    var h = readWs_(n, false), sc = schema_(h), idN = h.headers.indexOf(SYS.ID); if (idN < 0) return;
    var col = null;
    h.vals.forEach(function (r, k) {
      if (!hasContent_(r, sc)) return;
      var id = String(r[idN] === null ? '' : r[idN]); if (!id) return;
      if (seen[id]) {
        if (!col) col = h.vals.map(function (x) { return [x[idN]]; });
        var nid = fmtId_(allocIds_(1)); col[k][0] = nid; fixes++;
        logs.push({ action: 'ID_FIXED', id: nid, title: String(r[sc.titleIdx] || ''), ws: n, source: 'System', details: 'Doc ID ' + id + ' was already used in ' + seen[id] + '. Gave this row a new ID.' });
      } else seen[id] = n;
    });
    if (col) h.sheet.getRange(h.hr + 1, idN + 1, h.vals.length, 1).setValues(col);
  });
  if (fixes) { logBatch_(logs); bump_(); }
  return fixes;
}

/* ---------- access control: roles, plus which workstreams an editor may edit ---------- */
function parseEdit_(s) { return String(s || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean); }
/** Access list, cached for 5 minutes. Writers pass fresh=true and call accessDirty_() after changing it. */
function accessRows_(fresh) {
  var cache = CacheService.getScriptCache();
  if (!fresh) {
    if (_acc) return _acc;
    try { var raw = cache.get('acc'); if (raw) { _acc = JSON.parse(raw); return _acc; } } catch (e) {}
  }
  var s = sh_(TAB.ACCESS), n = s.getLastRow() - 1, rows = [];
  if (n > 0) rows = s.getRange(2, 1, n, 6).getValues().map(function (r, i) {
    return { row: i + 2, email: String(r[0]).toLowerCase().trim(), role: String(r[1]).toLowerCase().trim(), name: r[2],
             by: r[3], on: r[4] instanceof Date ? stamp_(r[4]) : String(r[4] || ''), edit: parseEdit_(r[5]) };
  }).filter(function (r) { return r.email; });
  try { cache.put('acc', JSON.stringify(rows), 300); } catch (e) {}
  _acc = rows; return rows;
}
function reqRows_() {
  var s = sh_(TAB.REQ), n = s.getLastRow() - 1; if (n < 1) return [];
  return s.getRange(2, 1, n, 10).getValues().map(function (r, i) {
    return { row: i + 2, id: r[0], email: String(r[1]).toLowerCase(), reason: r[2], status: r[3],
             on: r[4] instanceof Date ? stamp_(r[4]) : String(r[4] || ''), by: r[5],
             decided: r[6] instanceof Date ? stamp_(r[6]) : String(r[6] || ''), role: r[7],
             wsReq: parseEdit_(r[8]), wsGrant: parseEdit_(r[9]) };
  });
}
function userOf_(email) {
  var u = { email: email || '', role: 'none', edit: [] };
  if (!email) return u;
  var a = accessRows_();
  for (var i = 0; i < a.length; i++) if (a[i].email === email && RANK[a[i].role]) { u.role = a[i].role; u.edit = a[i].edit; break; }
  return u;
}
function roleOf_(email) { return userOf_(email).role; }
/** Owners and admins edit every workstream; an editor edits only the workstreams listed for them ("*" means all). */
function canEditWs_(u, ws) {
  if (u.role === 'owner' || u.role === 'admin') return true;
  return u.role === 'editor' && (u.edit.indexOf('*') >= 0 || u.edit.indexOf(ws) >= 0);
}
function editableWs_(u) { return wsNames_().filter(function (n) { return canEditWs_(u, n); }); }
function guard_(min) {
  var email = me_();
  if (!email) throw new Error('Sign in with your ' + DOMAIN + ' account to use this app.');
  if (!isDomain_(email)) throw new Error('This app is limited to ' + DOMAIN + ' accounts.');
  var u = userOf_(email);
  if (RANK[u.role] < RANK[min]) throw new Error('Your role (' + u.role + ') can\'t do that.');
  return u;
}
function guardWs_(ws) {
  var u = guard_('editor');
  if (wsNames_().indexOf(ws) < 0) throw new Error('Choose a workstream.');
  if (!canEditWs_(u, ws)) throw new Error('You can edit only your own workstreams. Ask an admin for edit access to ' + ws + '.');
  return u;
}
/** Only an owner may grant or change the admin and owner roles. */
function assertCanGrant_(u, role, targetRole) {
  if (u.role === 'owner') return;
  if (role === 'admin' || role === 'owner' || targetRole === 'admin' || targetRole === 'owner') throw new Error('Only an owner can grant or change admin and owner access.');
}

/* ---------- audit ---------- */
/** Writes several audit rows in one call (a single row uses appendRow, which is atomic). */
function logBatch_(list) {
  if (!list || !list.length) return;
  try {
    var s = sh_(TAB.LOG), now = new Date(), me = me_();
    var rows = list.map(function (o) {
      return [now, o.user || me, o.role || '', o.action, o.id || '', clip_(o.title), o.field || '', clip_(o.old), clip_(o.neu), o.source || 'App', clip_(o.details), o.ws || ''];
    });
    if (rows.length === 1) s.appendRow(rows[0]);
    else s.getRange(s.getLastRow() + 1, 1, rows.length, 12).setValues(rows);
  } catch (e) { console.error('log failed', e); }
}
function logEvent_(o) { logBatch_([o]); }

/* ---------- HOME text and Team directory (edited in the sheet) ---------- */
/** HOME tab, columns: A content, B style (Title, Heading, Text, Bullet, Note, Link, Spacer, Accent), C link.
 *  Bold text and links typed in column A come through as rich text. A HOME tab with no styles is read as the older one-column markup. */
function homeBlocks_() {
  var cache = CacheService.getScriptCache();
  try { var hit = cache.get('home'); if (hit) return JSON.parse(hit); } catch (e) {}
  var out = { v: 1, lines: [] }, s = ss_().getSheetByName(TAB.HOME);
  if (s && s.getLastRow() >= 1) {
    var n = Math.min(s.getLastRow(), 400), rng = s.getRange(1, 1, n, 3), vals = rng.getValues();
    var styled = vals.some(function (r) { return String(r[1]).trim() !== ''; });
    if (!styled) {
      var lines = vals.map(function (r) { return logCell_(r[0]); });
      while (lines.length && lines[lines.length - 1] === '') lines.pop();
      out = { v: 1, lines: lines };
    } else {
      var rich = null; try { rich = rng.getRichTextValues(); } catch (e) { rich = null; }
      var blocks = [], KINDS = { title: 1, heading: 1, text: 1, bullet: 1, note: 1, link: 1 };
      vals.forEach(function (r, i) {
        var st = String(r[1]).trim().toLowerCase(), text = logCell_(r[0]), link = safeHttp_(r[2]);
        if (st === 'spacer' || st === 'accent' || st === 'style') return;
        if (st === 'link') { if (text || link) blocks.push({ k: 'link', r: [{ t: text || link, b: false, u: link }] }); return; }
        if (!text.trim()) return;
        blocks.push({ k: KINDS[st] ? st : 'text', r: richRuns_(rich ? rich[i][0] : null, text) });
      });
      out = { v: 2, blocks: blocks };
    }
  }
  try { cache.put('home', JSON.stringify(out), 300); } catch (e) {}
  return out;
}
function safeHttp_(u) { u = String(u || '').trim(); return /^https?:\/\//i.test(u) ? u : ''; }
/** The bold and link runs of one cell, as plain data. */
function richRuns_(rv, fallback) {
  try {
    var runs = rv ? rv.getRuns() : null;
    if (runs && runs.length) {
      var out = runs.map(function (x) { return { t: String(x.getText()), b: !!x.getTextStyle().isBold(), u: safeHttp_(x.getLinkUrl()) }; }).filter(function (x) { return x.t !== ''; });
      if (out.length) return out;
    }
  } catch (e) {}
  return [{ t: fallback, b: false, u: '' }];
}

/** Team tab columns: Section, Workstream, Role, Org, Name, Note. */
function teamRows_() {
  var cache = CacheService.getScriptCache();
  try { var hit = cache.get('team'); if (hit) return JSON.parse(hit); } catch (e) {}
  var out = [], s = ss_().getSheetByName(TAB.TEAM);
  if (s && s.getLastRow() >= 2) {
    s.getRange(2, 1, Math.min(s.getLastRow() - 1, 500), 6).getValues().forEach(function (r) {
      var o = { s: logCell_(r[0]), w: logCell_(r[1]), r: logCell_(r[2]), o: logCell_(r[3]), n: logCell_(r[4]), t: logCell_(r[5]) };
      if (o.s || o.r || o.n) out.push(o);
    });
  }
  try { cache.put('team', JSON.stringify(out), 300); } catch (e) {}
  return out;
}
function contentDirty_() { try { CacheService.getScriptCache().removeAll(['home', 'team']); } catch (e) {} }

/* ---------- API: bootstrap and data ---------- */
function initInfo_() {
  var email = me_();
  var out = { email: email, role: 'none', domainOk: isDomain_(email), sheetUrl: '', cfg: pubConfig_(), pending: null, workstreams: [] };
  if (!email || !out.domainOk) return out;
  out.workstreams = wsNames_();
  out.role = userOf_(email).role;
  if (out.role === 'none' && /^(on|true|yes|1)$/i.test(String(cfg_().AUTO_VIEWER || '').trim())) {
    // Optional open-viewing mode: any signed-in company account becomes a viewer automatically. Editor, admin and owner still need approval.
    withLock_(function () {
      if (!accessRows_(true).some(function (a) { return a.email === email; })) {
        upsertAccess_(email, 'viewer', 'auto', []);
        logEvent_({ user: email, role: 'viewer', action: 'ACCESS_GRANTED', title: email, field: 'Role', neu: 'viewer', details: 'Automatic viewer access (AUTO_VIEWER is on)' });
      }
    });
    out.role = userOf_(email).role;
  }
  if (out.role === 'none') {
    var p = reqRows_().filter(function (r) { return r.email === email && r.status === 'Pending'; });
    out.pending = p.length ? p[0].on : null;
  } else if (RANK[out.role] >= RANK.editor) out.sheetUrl = sheetUrl_();
  return out;
}
function getInit() { return initInfo_(); }
/** One call returns identity and, when allowed, the whole dataset (used by doGet and as a fallback). */
function startup_() {
  var init = initInfo_(), out = { init: init, data: null };
  if (RANK[init.role] >= 1) out.data = buildDataset_(userOf_(init.email));
  return out;
}
function getStartup() { return startup_(); }
function getToken() { var u = guard_('viewer'); return { token: tokenNow_(), role: u.role, edit: editableWs_(u).join('|') }; }

function rowObj_(sc, r, rowNum, idN, ws) {
  var v = { Workstream: ws };
  for (var i = 0; i < sc.cols.length; i++) v[sc.cols[i].name] = fromCell_(r[sc.cols[i].index]);
  return { id: (idN >= 0 && r[idN]) ? String(r[idN]) : ('ROW-' + ws + '-' + rowNum), ws: ws, row: rowNum, ver: rowHash_(r, sc), v: v };
}
/** The part of the dataset that is the same for everyone. Built from the sheet, then shared through the cache. */
function buildShared_() {
  // The token is read BEFORE the tabs. If someone saves while we read, the snapshot is labelled with the older token and is never served as current.
  var token = tokenNow_();
  var names = wsNames_(), tabs = names.map(function (n) { return readWs_(n, false); }), scs = tabs.map(schema_);
  function audit() {
    var ids = {}, missing = false, dup = false;
    tabs.forEach(function (h, i) {
      var idN = h.headers.indexOf(SYS.ID); if (idN < 0) return;
      h.vals.forEach(function (r) {
        if (!hasContent_(r, scs[i])) return;
        var id = String(r[idN] === null ? '' : r[idN]);
        if (!id) { missing = true; return; }
        if (ids[id]) dup = true; else ids[id] = 1;
      });
    });
    return missing || dup;
  }
  if (audit()) {
    withLock_(function () { names.forEach(function (n) { fillMissingWs_(n, 'System'); }); dedupeIds_(); });
    token = tokenNow_();
    tabs = names.map(function (n) { return readWs_(n, false); }); scs = tabs.map(schema_);
  }
  var gHeaders = [], gF = {};
  tabs.forEach(function (h) {
    h.headers.forEach(function (n) { if (n && gHeaders.indexOf(n) < 0) gHeaders.push(n); });
    (h.fcols || []).forEach(function (n) { gF[n] = 1; });
  });
  var pseudo = { headers: gHeaders, vals: [], forms: [], hr: 3, lc: gHeaders.length, fcols: Object.keys(gF) };
  tabs.forEach(function (h) {
    h.map = gHeaders.map(function (n) { return h.headers.indexOf(n); });
    h.vals.forEach(function (r) { pseudo.vals.push(h.map.map(function (i) { return i >= 0 ? r[i] : ''; })); });
  });
  var gsc = schema_(pseudo);
  gsc.cols.unshift({ name: 'Workstream', index: -1, type: 'text', formula: false, readonly: true, system: true, categorical: true, hidden: false });
  gsc.roles.ws = 'Workstream';
  var rows = [], maxId = 0;
  tabs.forEach(function (h, ti) {
    var sc = scs[ti], idN = h.headers.indexOf(SYS.ID);
    for (var k = 0; k < h.vals.length; k++) {
      var r = h.vals[k]; if (!hasContent_(r, sc)) continue;
      var a = new Array(gsc.cols.length); a[0] = h.ws;
      for (var c = 1; c < gsc.cols.length; c++) { var gi = h.map[gsc.cols[c].index]; a[c] = gi >= 0 ? fromCell_(r[gi]) : ''; }
      var id = (idN >= 0 && r[idN]) ? String(r[idN]) : ('ROW-' + h.ws + '-' + (h.hr + 1 + k));
      var m = /^DOC-(\d+)$/.exec(id); if (m) maxId = Math.max(maxId, +m[1]);
      rows.push({ id: id, ws: h.ws, row: h.hr + 1 + k, ver: rowHash_(r, sc), a: a });
    }
  });
  try {
    var props = PropertiesService.getScriptProperties(), seq = props.getProperty('ID_SEQ');
    if (seq !== null && maxId > +seq) props.setProperty('ID_SEQ', String(maxId));
  } catch (e) {}
  var people = {}; accessRows_().forEach(function (a) { people[a.email] = a.name || ''; });
  var sharedTab = sharedName_();
  return { schema: gsc, rows: rows, workstreams: names.filter(function (n) { return n !== sharedTab; }), shared: sharedTab, token: token, today: iso_(new Date()), visits: visits_(), people: people, home: homeBlocks_(), team: teamRows_() };
}

/* ---- shared dataset cache: one rebuild serves every viewer until the next change ---- */
var DS_TTL = 180, DS_CHUNK = 90000;
function codeVer_() { return typeof SPEC_VERSION !== 'undefined' ? SPEC_VERSION : ''; }
function dsDay_() { return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd'); }
function dsKeys_(m) { var k = []; for (var i = 0; i < m.n; i++) k.push('ds:' + m.token + ':' + i); return k; }
/** The cached dataset, or null. Valid only for the current change token, the current day and this code version. */
function dsGet_() {
  try {
    var cache = CacheService.getScriptCache(), raw = cache.get('ds:meta'); if (!raw) return null;
    var m = JSON.parse(raw);
    if (m.v !== codeVer_() || m.day !== dsDay_() || m.token !== tokenNow_()) return null;
    var got = cache.getAll(dsKeys_(m)), s = '';
    for (var i = 0; i < m.n; i++) { var part = got['ds:' + m.token + ':' + i]; if (part === null || part === undefined) return null; s += part; }
    return JSON.parse(Utilities.ungzip(Utilities.newBlob(Utilities.base64Decode(s), 'application/x-gzip')).getDataAsString());
  } catch (e) { return null; }
}
function dsPut_(snap, token) {
  try {
    var cache = CacheService.getScriptCache();
    var b64 = Utilities.base64Encode(Utilities.gzip(Utilities.newBlob(JSON.stringify(snap), 'application/json')).getBytes());
    var n = Math.max(1, Math.ceil(b64.length / DS_CHUNK)), put = {};
    for (var i = 0; i < n; i++) put['ds:' + token + ':' + i] = b64.substr(i * DS_CHUNK, DS_CHUNK);
    var old = cache.get('ds:meta'); if (old) { try { cache.removeAll(dsKeys_(JSON.parse(old))); } catch (e) {} }
    put['ds:meta'] = JSON.stringify({ v: codeVer_(), day: dsDay_(), token: token, n: n });
    cache.putAll(put, DS_TTL);
  } catch (e) { console.error('dataset cache write failed', e); }
}
/** Cached dataset if there is one; otherwise exactly one request rebuilds it while the others wait and then read the cache. */
function sharedDataset_(fresh) {
  var t0 = Date.now(), snap = fresh ? null : dsGet_();
  if (snap) { snap.perf = { source: 'cache', ms: Date.now() - t0 }; return snap; }
  var lock = null, held = false;
  try { lock = LockService.getDocumentLock(); } catch (e) { lock = null; }
  if (lock) {
    try {
      held = lock.tryLock(0);
      if (!held && !fresh) {
        held = lock.tryLock(8000);
        if (held) { snap = dsGet_(); if (snap) { lock.releaseLock(); snap.perf = { source: 'cache', ms: Date.now() - t0, waited: true }; return snap; } }
      }
    } catch (e) { held = false; }
  }
  try {
    snap = buildShared_();
    dsPut_(snap, snap.token);
  } finally { if (held) { try { lock.releaseLock(); } catch (e) {} } }
  snap.perf = { source: 'rebuilt', ms: Date.now() - t0 };
  return snap;
}
/** Per-person part (role and editable workstreams) added to the shared dataset. */
function buildDataset_(u, fresh) {
  var s = sharedDataset_(fresh);
  return { schema: s.schema, rows: s.rows, workstreams: s.workstreams, shared: s.shared || '', token: s.token, today: s.today, visits: s.visits, people: s.people, home: s.home, team: s.team,
           perf: s.perf, role: u.role, me: { email: u.email, role: u.role, edit: editableWs_(u) } };
}

function getDataset(fresh) { var u = guard_('viewer'); return buildDataset_(u, !!fresh); }

/* ---------- API: create / update / delete / move / visit ---------- */
function dupLog_(u, id, title, urlName, url, others, ws) {
  return { user: u.email, role: u.role, action: 'DUPLICATE', id: id, title: title, field: urlName, neu: url, ws: ws || '',
           details: 'Same link as ' + others.map(function (o) { return o.id + ' (' + o.title + (o.ws ? ', ' + o.ws : '') + ')'; }).join(', ') };
}
/** Other documents in the SAME workstream that already use this link. The same link may appear in different workstreams. */
function dupInWs_(h, sc, url, excludeId) {
  var key = normUrl_(url), out = [];
  if (!key || sc.urlIdx < 0) return out;
  var idN = sc.roles.id ? h.headers.indexOf(sc.roles.id) : -1;
  for (var k = 0; k < h.vals.length; k++) {
    var r = h.vals[k]; if (!hasContent_(r, sc)) continue;
    var rid = idN >= 0 && r[idN] ? String(r[idN]) : '';
    if (excludeId && rid === String(excludeId)) continue;
    if (normUrl_(r[sc.urlIdx]) === key) out.push({ id: rid, title: String(r[sc.titleIdx] || ''), ws: h.ws });
  }
  return out;
}

function findRow_(h, sc, id) {
  var idN = sc.roles.id ? h.headers.indexOf(sc.roles.id) : -1;
  if (idN < 0) return -1;
  for (var i = 0; i < h.vals.length; i++) if (String(h.vals[i][idN]) === String(id)) return i;
  return -1;
}
function saveDoc(p) {
  var ws = String((p && p.ws) || ''), u = guardWs_(ws);
  return withLock_(function () {
    var ctx = { since: p.since || '', before: tokenNow_() };
    return p.id ? updateDoc_(u, p, ctx, ws) : createDoc_(u, p, ctx, ws);
  });
}
/** After a write: reads just that row back, updates the shadow copy, bumps the change token and returns the fresh row. */
function finishWrite_(h, sc, rowNum, ctx, res) {
  var r = h.sheet.getRange(rowNum, 1, 1, h.lc).getValues()[0];
  var idN = sc.roles.id ? h.headers.indexOf(sc.roles.id) : -1;
  if (idN >= 0 && r[idN]) shadowUpsert_([{ id: String(r[idN]), ws: h.ws, json: JSON.stringify(snapObj_(sc, r)) }]);
  bump_();
  res.row = rowObj_(sc, r, rowNum, idN, h.ws);
  res.token = tokenNow_();
  res.fresh = !!(ctx && ctx.since && ctx.since === ctx.before);
  return res;
}
function createDoc_(u, p, ctx, ws) {
  var h = readWs_(ws, true), sc = schema_(h), rl = sc.roles, v = prepAssign_(ws, sc, p.values || {}, true);
  var title = String(v[rl.title] || '').trim();
  if (!title) throw new Error('Enter a title.');
  if (rl.url && !/^https?:\/\//i.test(String(v[rl.url] || '').trim())) throw new Error('Enter a URL that starts with http:// or https://');
  var dups = rl.url ? dupInWs_(h, sc, v[rl.url], '') : [];
  var ins = insertRow_(h, sc, v, u, { keepMod: true });
  var logs = [{ user: u.email, role: u.role, action: 'CREATE', id: ins.id, title: title, ws: ws, details: 'Added from the dashboard' }];
  if (dups.length) logs.push(dupLog_(u, ins.id, title, rl.url, v[rl.url], dups, ws));
  logBatch_(logs);
  folderLearn_(p.folder, v, rl);
  return finishWrite_(h, sc, ins.row, ctx, { ok: true, id: ins.id, dups: dups });
}
function updateDoc_(u, p, ctx, ws) {
  var h = readWs_(ws, true), sc = schema_(h), rl = sc.roles, v = prepAssign_(ws, sc, p.values || {}, false);
  var k = findRow_(h, sc, p.id);
  if (k < 0) return { ok: false, notFound: true, message: 'This document is no longer in ' + ws + '. Refreshing.' };
  var r = h.vals[k];
  if (p.ver && rowHash_(r, sc) !== p.ver) return { ok: false, conflict: true, message: 'Someone changed this document while you were editing. Your edits weren\'t saved. Refreshing.' };
  var changes = [], manualMod = false;
  sc.cols.forEach(function (c) {
    if (c.readonly || !(c.name in v)) return;
    var nv = toCell_(c.type, v[c.name]), ov = r[c.index];
    if (String(fromCell_(nv)) === String(fromCell_(ov))) return;
    changes.push({ c: c, nv: nv, ov: ov });
    if (c.name === rl.mod) manualMod = true;
  });
  if (!changes.length) return { ok: true, nochange: true };
  var title = rl.title ? String(r[h.headers.indexOf(rl.title)] || '') : '';
  changes.forEach(function (ch) {
    if (ch.c.name === rl.title && !ch.nv) throw new Error('Title can\'t be empty.');
    if (ch.c.name === rl.url && !/^https?:\/\//i.test(String(ch.nv))) throw new Error('Enter a URL that starts with http:// or https://');
  });
  var updates = {}, logs = [];
  changes.forEach(function (ch) {
    updates[ch.c.index] = ch.nv;
    logs.push({ user: u.email, role: u.role, action: 'UPDATE', id: p.id, title: ch.c.name === rl.title ? ch.nv : title, ws: ws,
                field: ch.c.name, old: fromCell_(ch.ov), neu: fromCell_(ch.nv) });
  });
  var urlC = rl.url ? colByName_(sc, rl.url) : null, tyC = rl.type ? colByName_(sc, rl.type) : null;
  if (urlC && tyC && changes.some(function (ch) { return ch.c.name === rl.url; })) updates[tyC.index] = detectType_(v[rl.url]);
  var mC = rl.mod ? colByName_(sc, rl.mod) : null, bC = rl.by ? colByName_(sc, rl.by) : null;
  if (mC && !manualMod) updates[mC.index] = today_();
  if (bC) updates[bC.index] = u.email;
  var dups = [];
  if (urlC && changes.some(function (ch) { return ch.c.name === rl.url; })) {
    dups = dupInWs_(h, sc, v[rl.url], p.id);
    if (dups.length) logs.push(dupLog_(u, p.id, title, rl.url, v[rl.url], dups, ws));
  }
  writeSpan_(h, k, updates);
  fixMissingFormulas_(h, sc, [{ k: k, updates: updates }]);
  logBatch_(logs);
  return finishWrite_(h, sc, h.hr + 1 + k, ctx, { ok: true, dups: dups });
}
function deleteDoc(id, reason, since, ws) {
  ws = String(ws || ''); var u = guardWs_(ws);
  return withLock_(function () {
    var before = tokenNow_();
    var h = readWs_(ws, false), sc = schema_(h), rl = sc.roles, k = findRow_(h, sc, id);
    if (k < 0) return { ok: false, notFound: true, message: 'This document is already gone. Refreshing.' };
    var snap = {}; sc.cols.forEach(function (c) { snap[c.name] = fromCell_(h.vals[k][c.index]); });
    var title = snap[rl.title] || '', url = rl.url ? snap[rl.url] : '';
    sh_(TAB.ARCHIVE).appendRow([id, title, url, new Date(), u.email, String(reason || '').slice(0, 300), JSON.stringify(snap), ws]);
    h.sheet.deleteRow(h.hr + 1 + k);
    logEvent_({ user: u.email, role: u.role, action: 'DELETE', id: id, title: title, ws: ws, details: 'Moved to Archive. ' + (reason || '') });
    shadowRemove_(id); bump_();
    return { ok: true, removed: id, token: tokenNow_(), fresh: !!(since && since === before && String(id).indexOf('ROW-') !== 0) };
  });
}
function markVisited(id, since, ws) {
  ws = String(ws || ''); var u = guardWs_(ws);
  return withLock_(function () {
    var ctx = { since: since || '', before: tokenNow_() };
    var h = readWs_(ws, true), sc = schema_(h), rl = sc.roles;
    if (!rl.latest) throw new Error('Add a "Latest Visit" column to the sheet to track visits.');
    var k = findRow_(h, sc, id); if (k < 0) return { ok: false, notFound: true, message: 'This document is no longer in ' + ws + '. Refreshing.' };
    var lc = colByName_(sc, rl.latest), old = h.vals[k][lc.index], updates = {};
    updates[lc.index] = today_();
    var mC = rl.mod ? colByName_(sc, rl.mod) : null, bC = rl.by ? colByName_(sc, rl.by) : null;
    if (mC) updates[mC.index] = today_();
    if (bC) updates[bC.index] = u.email;
    writeSpan_(h, k, updates);
    fixMissingFormulas_(h, sc, [{ k: k, updates: updates }]);
    logEvent_({ user: u.email, role: u.role, action: 'VISIT', id: id, title: h.vals[k][h.headers.indexOf(rl.title)], ws: ws, field: rl.latest, old: fromCell_(old), neu: iso_(new Date()) });
    try { CacheService.getScriptCache().remove('visits'); } catch (e) {}
    return finishWrite_(h, sc, h.hr + 1 + k, ctx, { ok: true });
  });
}
/** Moves a document to another workstream tab. It keeps its Doc ID, Date Added and Added By. */
function moveDoc(id, fromWs, toWs, since, assigned) {
  fromWs = String(fromWs || ''); toWs = String(toWs || '');
  var u = guardWs_(fromWs); guardWs_(toWs);
  if (fromWs === toWs) throw new Error('Choose a different workstream.');
  return withLock_(function () {
    var ctx = { since: since || '', before: tokenNow_() };
    var src = readWs_(fromWs, false), ssc = schema_(src), k = findRow_(src, ssc, id);
    if (k < 0) return { ok: false, notFound: true, message: 'This document is no longer in ' + fromWs + '. Refreshing.' };
    var snap = {}; ssc.cols.forEach(function (c) { snap[c.name] = fromCell_(src.vals[k][c.index]); });
    if (toWs === sharedName_()) snap[ASSIGN] = normAssign_(assigned); else delete snap[ASSIGN];
    var dst = readWs_(toWs, true), dsc = schema_(dst);
    var dups = dsc.roles.url ? dupInWs_(dst, dsc, snap[ssc.roles.url], id) : [];
    var ins = insertRow_(dst, dsc, snap, u, { id: id, keepAddedBy: true });
    src.sheet.deleteRow(src.hr + 1 + k);
    var mlogs = [{ user: u.email, role: u.role, action: 'MOVE', id: id, title: snap[ssc.roles.title] || '', ws: toWs, field: 'Workstream', old: fromWs, neu: toWs, details: 'Moved from ' + fromWs + ' to ' + toWs }];
    if (dups.length) mlogs.push(dupLog_(u, id, snap[ssc.roles.title] || '', dsc.roles.url, snap[ssc.roles.url], dups, toWs));
    logBatch_(mlogs);
    return finishWrite_(dst, dsc, ins.row, ctx, { ok: true, moved: true, dups: dups });
  });
}

// ===== Fill a new document from its Google link =====
var LOOKUP_NO = 'Couldn\'t fill this in from the link. It may be private or not shared with you. Type the title yourself.';
var FOLDERS_HDR = ['Folder ID', 'Folder Name', 'Project', 'L_1', 'L_2', 'L_3', 'Times used', 'Last used'];

/** The Drive file or folder ID inside a Google link (Docs, Sheets, Slides, Forms, Drawings, Drive files and folders), or ''. */
function parseDriveLink_(url) {
  var u = String(url || '').trim();
  if (!/^https:\/\/(docs|drive)\.google\.com\//i.test(u)) return '';
  var m = u.match(/\/(?:document|spreadsheets|presentation|forms|drawings|file)\/(?:u\/\d+\/)?d\/([A-Za-z0-9_-]{15,})/i)
       || u.match(/\/folders\/([A-Za-z0-9_-]{15,})/i)
       || u.match(/[?&]id=([A-Za-z0-9_-]{15,})/i);
  return m ? m[1] : '';
}
function kindOf_(mime) {
  var m = String(mime || '');
  if (m === 'application/vnd.google-apps.spreadsheet') return 'Google Sheet';
  if (m === 'application/vnd.google-apps.document') return 'Google Doc';
  if (m === 'application/vnd.google-apps.presentation') return 'Google Slides';
  if (m === 'application/vnd.google-apps.form') return 'Google Form';
  if (m === 'application/vnd.google-apps.folder') return 'Drive folder';
  return 'Drive file';
}
/** Name, owner, parent folder and sharing of a Drive item. Uses the Drive service when it is enabled, otherwise DriveApp. perms is null when sharing is not visible. */
function driveMeta_(id) {
  var cache = CacheService.getScriptCache(), key = 'dl:' + id;
  try { var hit = cache.get(key); if (hit) return JSON.parse(hit); } catch (e) {}
  var m = null;
  if (typeof Drive !== 'undefined' && Drive && Drive.Files) {
    try {
      var f = Drive.Files.get(id, { fields: 'id,name,mimeType,description,modifiedTime,parents,owners(emailAddress),permissions(type,role,emailAddress,domain)', supportsAllDrives: true });
      m = { name: f.name || '', mime: f.mimeType || '', description: f.description || '', modified: f.modifiedTime || '',
            owner: (f.owners && f.owners[0] && f.owners[0].emailAddress) || '', parent: (f.parents && f.parents[0]) || '',
            perms: f.permissions ? f.permissions.map(function (p) { return { type: p.type, role: p.role, email: p.emailAddress || '', domain: p.domain || '' }; }) : null };
    } catch (e) { m = null; }
  }
  if (!m) m = driveMetaApp_(id);
  if (m) { try { cache.put(key, JSON.stringify(m), 300); } catch (e) {} }
  return m;
}
function driveMetaApp_(id) {
  var f = null, folder = false;
  try { f = DriveApp.getFileById(id); } catch (e) { try { f = DriveApp.getFolderById(id); folder = true; } catch (e2) { return null; } }
  var owner = ''; try { owner = f.getOwner() ? f.getOwner().getEmail() : ''; } catch (e) {}
  var perms = [], acc = ''; try { acc = String(f.getSharingAccess()); } catch (e) {}
  if (acc === 'ANYONE' || acc === 'ANYONE_WITH_LINK') perms.push({ type: 'anyone', role: 'reader', email: '', domain: '' });
  if ((acc === 'DOMAIN' || acc === 'DOMAIN_WITH_LINK') && owner) perms.push({ type: 'domain', role: 'reader', email: '', domain: owner.split('@')[1] || '' });
  try { f.getEditors().concat(f.getViewers()).forEach(function (x) { perms.push({ type: 'user', role: 'reader', email: x.getEmail(), domain: '' }); }); } catch (e) {}
  if (owner) perms.push({ type: 'user', role: 'owner', email: owner, domain: '' });
  var parent = ''; try { var it = f.getParents(); if (it.hasNext()) parent = it.next().getId(); } catch (e) {}
  var mod = ''; try { mod = f.getLastUpdated().toISOString(); } catch (e) {}
  var desc = ''; try { desc = f.getDescription() || ''; } catch (e) {}
  return { name: f.getName(), mime: folder ? 'application/vnd.google-apps.folder' : f.getMimeType(), description: desc, modified: mod, owner: owner, parent: parent, perms: perms };
}
/** True only when the sharing list shows that this person can open the item (named, their whole domain, anyone, or owner). Groups are not resolved. */
function canOpen_(meta, email) {
  email = String(email || '').toLowerCase();
  var dom = email.split('@')[1] || '';
  if (!meta || !meta.perms || !email) return false;
  if (String(meta.owner || '').toLowerCase() === email) return true;
  return meta.perms.some(function (p) {
    if (p.type === 'anyone') return true;
    if (p.type === 'domain') return !!dom && String(p.domain || p.email || '').toLowerCase() === dom;
    if (p.type === 'user') return String(p.email || '').toLowerCase() === email;
    return false;
  });
}
function lookupRate_(email) {
  var cache = CacheService.getScriptCache(), key = 'dlr:' + email, n = 0;
  try { n = +cache.get(key) || 0; } catch (e) {}
  if (n >= 30) return false;
  try { cache.put(key, String(n + 1), 60); } catch (e) {}
  return true;
}
/** Reads a Google link for the Add form: title, notes, and the folders above it. Nothing is returned unless the person could open the file themselves. */
function lookupLink(url, ws) {
  ws = String(ws || '');
  var u = guardWs_(ws);
  if (!lookupRate_(u.email)) return { ok: false, message: 'Too many lookups in a minute. Wait a moment, or type the title yourself.' };
  var id = parseDriveLink_(url);
  if (!id) return { ok: false, unsupported: true, message: 'Only Google Docs, Sheets, Slides, Forms and Drive links can be read. Type the title yourself.' };
  var meta = null; try { meta = driveMeta_(id); } catch (e) { meta = null; }
  if (!meta || !canOpen_(meta, u.email)) return { ok: false, message: LOOKUP_NO };
  var chain = [], pid = meta.parent;
  for (var d = 0; d < 4 && pid; d++) {
    var fm = null; try { fm = driveMeta_(pid); } catch (e) { fm = null; }
    if (!fm || !canOpen_(fm, u.email)) break;
    chain.push({ id: pid, name: String(fm.name || '').replace(/\s+/g, ' ').trim() });
    pid = fm.parent;
  }
  var learned = meta.parent ? folderGet_(meta.parent) : null;
  return { ok: true, id: id, kind: kindOf_(meta.mime), title: String(meta.name || '').replace(/\s+/g, ' ').trim(),
           note: String(meta.description || '').trim(), modified: meta.modified || '',
           folder: meta.parent ? { id: meta.parent, name: chain[0] ? chain[0].name : '' } : null,
           chain: chain.map(function (x) { return x.name; }), learned: learned };
}
// Folder memory: which categories a Drive folder's documents were filed under, learned from each document added through the form.
function foldersSheet_(create) {
  var s = ss_().getSheetByName(TAB.FOLDERS);
  if (!s && create) {
    s = ss_().insertSheet(TAB.FOLDERS);
    s.getRange(1, 1, 1, FOLDERS_HDR.length).setValues([FOLDERS_HDR]).setFontWeight('bold');
    s.setFrozenRows(1);
    try { s.hideSheet(); } catch (e) {}
  }
  return s;
}
function folderGet_(id) {
  var s = foldersSheet_(false); if (!s || s.getLastRow() < 2) return null;
  var v = s.getRange(2, 1, s.getLastRow() - 1, FOLDERS_HDR.length).getValues();
  for (var i = 0; i < v.length; i++) {
    if (String(v[i][0]) === id) return { project: String(v[i][2] || ''), l1: String(v[i][3] || ''), l2: String(v[i][4] || ''), l3: String(v[i][5] || '') };
  }
  return null;
}
function safeText_(x) { x = String(x === undefined || x === null ? '' : x).trim(); return /^[=+\-@]/.test(x) ? "'" + x : x; }
function folderLearn_(folder, v, rl) {
  try {
    if (!folder || !/^[A-Za-z0-9_-]{10,}$/.test(String(folder.id || ''))) return;
    var cats = [rl.project, rl.l1, rl.l2, rl.l3].map(function (c) { return c ? safeText_(v[c]) : ''; });
    if (!cats.some(Boolean)) return;
    var s = foldersSheet_(true), id = String(folder.id), name = safeText_(String(folder.name || '').slice(0, 200)), n = s.getLastRow(), row = -1;
    if (n >= 2) { var ids = s.getRange(2, 1, n - 1, 1).getValues(); for (var i = 0; i < ids.length; i++) if (String(ids[i][0]) === id) { row = i + 2; break; } }
    var used = row > 0 ? (+s.getRange(row, 7).getValue() || 0) + 1 : 1;
    var line = [id, name, cats[0], cats[1], cats[2], cats[3], used, new Date()];
    if (row > 0) s.getRange(row, 1, 1, line.length).setValues([line]); else s.appendRow(line);
  } catch (e) { console.error('folderLearn_', e); }
}

/** Merges copies of the same document from several workstreams into the shared area.
 *  items = [{id, ws}]; the first copy is kept (same Doc ID), the others go to the Archive. */
function mergeToShared(items, title, assigned) {
  var shared = sharedName_(); if (!shared) throw new Error('There is no shared area. Add a tab named "' + cfg_().SHARED_TAB + '".');
  items = (items || []).filter(function (x) { return x && x.id && x.ws; });
  if (items.length < 2) throw new Error('Choose at least two copies to merge.');
  var u = guardWs_(shared);
  items.forEach(function (it) {
    if (it.ws === shared) throw new Error('A copy is already in ' + shared + '.');
    if (!canEditWs_(u, it.ws)) throw new Error('Merging copies across workstreams needs edit access to each of them. Ask an admin.');
  });
  var assign = normAssign_(assigned);
  return withLock_(function () {
    var ctx = { since: '', before: tokenNow_() };
    var base = items[0], bh = readWs_(base.ws, false), bsc = schema_(bh), bk = findRow_(bh, bsc, base.id);
    if (bk < 0) return { ok: false, notFound: true, message: 'One of the copies is no longer there. Refreshing.' };
    var snap = {}; bsc.cols.forEach(function (c) { snap[c.name] = fromCell_(bh.vals[bk][c.index]); });
    if (title && String(title).trim()) snap[bsc.roles.title] = String(title).trim();
    snap[ASSIGN] = assign;
    var dst = readWs_(shared, true), dsc = schema_(dst);
    var ins = insertRow_(dst, dsc, snap, u, { id: base.id, keepAddedBy: true });
    bh.sheet.deleteRow(bh.hr + 1 + bk);
    var removed = [base.id + ' (' + base.ws + ')'];
    items.slice(1).forEach(function (it) {
      var h = readWs_(it.ws, false), sc = schema_(h), k = findRow_(h, sc, it.id); if (k < 0) return;
      var s = {}; sc.cols.forEach(function (c) { s[c.name] = fromCell_(h.vals[k][c.index]); });
      sh_(TAB.ARCHIVE).appendRow([it.id, s[sc.roles.title] || '', sc.roles.url ? s[sc.roles.url] : '', new Date(), u.email, 'Merged into ' + shared + ' as ' + base.id, JSON.stringify(s), it.ws]);
      h.sheet.deleteRow(h.hr + 1 + k); shadowRemove_(it.id);
      removed.push(it.id + ' (' + it.ws + ')');
    });
    logEvent_({ user: u.email, role: u.role, action: 'MERGE', id: base.id, title: snap[bsc.roles.title] || '', ws: shared, field: ASSIGN, neu: assign, details: 'Merged ' + items.length + ' copies into ' + shared + ': ' + removed.join(', ') });
    return finishWrite_(dst, dsc, ins.row, ctx, { ok: true, merged: items.length });
  });
}
/** Restores an archived document into the workstream it came from (admin or owner). */
function restoreDoc(id) {
  var u = guard_('admin');
  return withLock_(function () {
    var a = sh_(TAB.ARCHIVE), n = a.getLastRow() - 1; if (n < 1) throw new Error('Archive is empty.');
    var vals = a.getRange(2, 1, n, 8).getValues(), at = -1;
    for (var i = vals.length - 1; i >= 0; i--) if (String(vals[i][0]) === id) { at = i; break; }
    if (at < 0) throw new Error('That archived document wasn\'t found.');
    var snap = {}; try { snap = JSON.parse(vals[at][6]); } catch (e) {}
    var ws = String(vals[at][7] || snap.Workstream || '');
    if (wsNames_().indexOf(ws) < 0) throw new Error('The workstream "' + ws + '" no longer exists. Add its tab back, then restore.');
    var h = readWs_(ws, true), sc = schema_(h);
    insertRow_(h, sc, snap, u, { id: id, keepAddedBy: true });
    a.deleteRow(at + 2);
    logEvent_({ user: u.email, role: u.role, action: 'RESTORE', id: id, title: vals[at][1], ws: ws, details: 'Restored from Archive' });
    refreshShadow_(); bump_();
    return { ok: true };
  });
}
/** Repairs every row, in every workstream, that has a schedule but is missing its Next Visit formula. */
function repairNextVisits_() {
  var n = 0;
  wsNames_().forEach(function (name) {
    var h = readWs_(name, true), sc = schema_(h), targets = [];
    h.vals.forEach(function (r, k) { if (hasContent_(r, sc)) targets.push({ k: k, updates: null }); });
    n += fixMissingFormulas_(h, sc, targets);
  });
  if (n) bump_();
  return n;
}
function repairNextVisits() {
  var u = guard_('admin');
  return withLock_(function () {
    var n = repairNextVisits_();
    if (n) logEvent_({ user: u.email, role: u.role, action: 'REPAIR', title: 'Next Visit formulas', details: 'Wrote the Next Visit formula into ' + n + ' cell(s).' });
    return { ok: true, fixed: n, token: tokenNow_() };
  });
}

/* ---------- API: governance ---------- */
function getGovernance() {
  var u = guard_('viewer');
  var out = { me: u, users: [], requests: [], archive: [], strayEditors: [], appUrl: appUrl_(), workstreams: wsNames_() };
  if (RANK[u.role] >= RANK.admin) {
    out.conn = { name: ss_().getName(), id: SS_ID, url: ss_().getUrl(), tab: (wsNames_().length - (sharedName_() ? 1 : 0)) + ' workstream tabs' + (sharedName_() ? ' and the shared area' : ''), version: (typeof SPEC_VERSION !== 'undefined' ? SPEC_VERSION : ''), appTitle: cfg_().APP_TITLE };
    out.users = accessRows_(true); out.requests = reqRows_().reverse();
    var a = sh_(TAB.ARCHIVE), n = a.getLastRow() - 1;
    if (n > 0) out.archive = a.getRange(2, 1, n, 8).getValues().map(function (r) {
      return { id: r[0], title: r[1], url: r[2], on: r[3] instanceof Date ? stamp_(r[3]) : String(r[3]), by: r[4], reason: r[5], ws: r[7] };
    }).reverse();
    try {
      var known = out.users.map(function (x) { return x.email; });
      var ownerEmail = ss_().getOwner() ? ss_().getOwner().getEmail().toLowerCase() : '';
      out.strayEditors = ss_().getEditors().map(function (x) { return x.getEmail().toLowerCase(); })
        .filter(function (e) { return known.indexOf(e) < 0 && e !== ownerEmail; });
    } catch (e) {}
  }
  return out;
}
function requestAccess(reason, wsList) {
  var email = me_();
  if (!email || !isDomain_(email)) throw new Error('Sign in with your ' + DOMAIN + ' account to request access.');
  return withLock_(function () {
    if (roleOf_(email) !== 'none') return { ok: true, already: true };
    if (reqRows_().some(function (r) { return r.email === email && r.status === 'Pending'; })) return { ok: true, pending: true };
    var id = 'REQ-' + Utilities.getUuid().slice(0, 8).toUpperCase();
    var want = (wsList || []).filter(function (n) { return wsNames_().indexOf(n) >= 0; });
    sh_(TAB.REQ).appendRow([id, email, String(reason || '').slice(0, 500), 'Pending', new Date(), '', '', '', want.join(', '), '']);
    logEvent_({ user: email, role: 'none', action: 'ACCESS_REQUEST', id: id, details: (reason || '') + (want.length ? ' | Wants to edit: ' + want.join(', ') : '') });
    var approvers = accessRows_().filter(function (r) { return r.role === 'owner' || r.role === 'admin'; }).map(function (r) { return r.email; });
    if (approvers.length) {
      try {
        MailApp.sendEmail({ to: approvers.join(','), subject: 'Access request for ' + cfg_().APP_TITLE + ': ' + email,
          htmlBody: '<p><b>' + email + '</b> asked for access to ' + cfg_().APP_TITLE + '.</p><p>Reason: ' + (reason || 'None given') +
                    (want.length ? '</p><p>Wants to edit: ' + want.join(', ') : '') +
                    '</p><p>Open the <b>Governance</b> tab to approve or deny and to choose their access.</p>' +
                    (appUrl_() ? '<p><a href="' + appUrl_() + '">Open the app</a></p>' : '') });
      } catch (e) { console.error('mail failed', e); }
    }
    bump_();
    return { ok: true };
  });
}
function upsertAccess_(email, role, by, edit) {
  var s = sh_(TAB.ACCESS), a = accessRows_(true), editStr = (edit || []).join(', ');
  for (var i = 0; i < a.length; i++) if (a[i].email === email) {
    s.getRange(a[i].row, 2, 1, 1).setValue(role); s.getRange(a[i].row, 4, 1, 3).setValues([[by, new Date(), editStr]]); accessDirty_(); return;
  }
  s.appendRow([email, role, '', by, new Date(), editStr]);
  accessDirty_();
}
function cleanEdit_(edit) {
  var names = wsNames_(), out = [];
  (edit || []).forEach(function (n) { n = String(n).trim(); if (n === '*') out = ['*']; else if (names.indexOf(n) >= 0 && out.indexOf('*') < 0 && out.indexOf(n) < 0) out.push(n); });
  return out;
}
function decideRequest(reqId, decision, role, edit) {
  var u = guard_('admin');
  return withLock_(function () {
    var r = reqRows_().filter(function (x) { return x.id === reqId; })[0];
    if (!r) throw new Error('Request not found.');
    if (r.status !== 'Pending') throw new Error('This request was already ' + r.status.toLowerCase() + '.');
    var approve = decision === 'approve';
    if (approve && ROLE_LIST.indexOf(role) < 0) throw new Error('Choose viewer, editor, admin, or owner.');
    if (approve) assertCanGrant_(u, role, 'none');
    var grant = role === 'editor' ? cleanEdit_(edit) : [];
    if (approve && role === 'editor' && !grant.length) throw new Error('Choose at least one workstream for an editor.');
    var s = sh_(TAB.REQ);
    s.getRange(r.row, 4).setValue(approve ? 'Approved' : 'Denied');
    s.getRange(r.row, 6, 1, 3).setValues([[u.email, new Date(), approve ? role : '']]);
    s.getRange(r.row, 10).setValue(approve ? grant.join(', ') : '');
    if (approve) { upsertAccess_(r.email, role, u.email, grant); syncPermissions_(); }
    logEvent_({ user: u.email, role: u.role, action: approve ? 'ACCESS_GRANTED' : 'ACCESS_DENIED', id: reqId, title: r.email, field: 'Role', neu: approve ? role + (grant.length ? ' (' + grant.join(', ') + ')' : '') : '' });
    try {
      MailApp.sendEmail({ to: r.email, subject: cfg_().APP_TITLE + ': access ' + (approve ? 'approved' : 'denied'),
        htmlBody: approve ? '<p>You now have <b>' + role + '</b> access' + (grant.length ? ' to edit: ' + grant.join(', ') : '') + '.</p>' + (appUrl_() ? '<p><a href="' + appUrl_() + '">Open the app</a></p>' : '')
                          : '<p>Your access request wasn\'t approved. Contact ' + u.email + ' for details.</p>' });
    } catch (e) {}
    bump_();
    return { ok: true };
  });
}
/** Sets a person's role and, for editors, the workstreams they may edit. Admins manage viewers and editors; only owners touch admin and owner. */
function setUserAccess(email, role, edit) {
  var u = guard_('admin'); email = String(email || '').toLowerCase().trim();
  if (!isDomain_(email)) throw new Error('Use a ' + DOMAIN + ' email address.');
  if (ROLE_LIST.indexOf(role) < 0) throw new Error('Choose viewer, editor, admin, or owner.');
  return withLock_(function () {
    var a = accessRows_(true), cur = a.filter(function (x) { return x.email === email; })[0];
    assertCanGrant_(u, role, cur ? cur.role : 'none');
    var owners = a.filter(function (x) { return x.role === 'owner'; });
    if (owners.length === 1 && owners[0].email === email && role !== 'owner') throw new Error('Keep at least one owner.');
    var grant = role === 'editor' ? cleanEdit_(edit) : [];
    var old = cur ? cur.role + (cur.edit.length ? ' (' + cur.edit.join(', ') + ')' : '') : 'none';
    upsertAccess_(email, role, u.email, grant); syncPermissions_();
    logEvent_({ user: u.email, role: u.role, action: 'ROLE_CHANGE', title: email, field: 'Role', old: old, neu: role + (grant.length ? ' (' + grant.join(', ') + ')' : '') });
    bump_(); return { ok: true };
  });
}
function setUserRole(email, role) { return setUserAccess(email, role, role === 'editor' ? ['*'] : []); }
function setUserName(email, name) {
  var u = guard_('admin'); email = String(email || '').toLowerCase();
  return withLock_(function () {
    var t = accessRows_(true).filter(function (x) { return x.email === email; })[0];
    if (!t) throw new Error('User not found.');
    assertCanGrant_(u, t.role, t.role);
    var clean = String(name || '').trim().slice(0, 60);
    sh_(TAB.ACCESS).getRange(t.row, 3).setValue(clean); accessDirty_();
    logEvent_({ user: u.email, role: u.role, action: 'ROLE_CHANGE', title: email, field: 'Display name', old: t.name, neu: clean });
    bump_(); return { ok: true };
  });
}
function removeUser(email) {
  var u = guard_('admin'); email = String(email || '').toLowerCase();
  return withLock_(function () {
    var a = accessRows_(true), t = a.filter(function (x) { return x.email === email; })[0];
    if (!t) throw new Error('User not found.');
    assertCanGrant_(u, t.role, t.role);
    var owners = a.filter(function (x) { return x.role === 'owner'; });
    if (t.role === 'owner' && owners.length === 1) throw new Error('Keep at least one owner.');
    sh_(TAB.ACCESS).deleteRow(t.row); accessDirty_();
    try { ss_().removeEditor(email); } catch (e) {}
    logEvent_({ user: u.email, role: u.role, action: 'ROLE_CHANGE', title: email, field: 'Role', old: t.role, neu: 'removed' });
    bump_(); return { ok: true };
  });
}
function syncPermissions_() {
  var book = ss_(), rows = accessRows_(), ownerEmail = '';
  try { ownerEmail = book.getOwner() ? book.getOwner().getEmail().toLowerCase() : ''; } catch (e) {}
  var cur = []; try { cur = book.getEditors().map(function (x) { return x.getEmail().toLowerCase(); }); } catch (e) {}
  rows.forEach(function (r) {
    if (r.email === ownerEmail) return;
    try {
      if (RANK[r.role] >= RANK.editor) { if (cur.indexOf(r.email) < 0) book.addEditor(r.email); }
      else if (r.role === 'viewer') { if (cur.indexOf(r.email) >= 0) book.removeEditor(r.email); }   // viewers use the app only; no direct sheet access
    } catch (e) { console.error('perm sync', r.email, e); }
  });
}
function syncSheetPermissions() { guard_('admin'); syncPermissions_(); logEvent_({ action: 'PERMISSIONS_SYNC', details: 'Sheet sharing aligned to Access tab' }); return { ok: true }; }

/* ---------- shadow copy (lets direct sheet deletions be archived) ---------- */
/** Full rebuild of the shadow copy (setup and structural changes only). */
function refreshShadow_() {
  var sh = ss_().getSheetByName(TAB.SHADOW); if (!sh) return;
  var rows = [], now = new Date();
  wsNames_().forEach(function (n) {
    var h = readWs_(n, false), sc = schema_(h), idN = h.headers.indexOf(SYS.ID);
    h.vals.forEach(function (r) {
      var id = idN >= 0 ? r[idN] : ''; if (!id) return;
      rows.push([String(id), JSON.stringify(snapObj_(sc, r)), now, n]);
    });
  });
  if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, Math.max(4, sh.getLastColumn())).clearContent();
  if (rows.length) sh.getRange(2, 1, rows.length, 4).setValues(rows);
}
function shadowUpsert_(items) {
  if (!items || !items.length) return;
  var sh = ss_().getSheetByName(TAB.SHADOW); if (!sh) return;
  var n = sh.getLastRow() - 1, now = new Date(), add = [];
  if (n > 0 && items.length <= 4) {
    // A few rows (the normal case): a server-side text search per row beats reading the whole ID column.
    items.forEach(function (it) {
      var f = sh.getRange(2, 1, n, 1).createTextFinder(it.id).matchEntireCell(true).findNext();
      if (f) sh.getRange(f.getRow(), 1, 1, 4).setValues([[it.id, it.json, now, it.ws || '']]);
      else add.push([it.id, it.json, now, it.ws || '']);
    });
  } else {
    var pos = {};
    if (n > 0) sh.getRange(2, 1, n, 1).getValues().forEach(function (r, i) { pos[String(r[0])] = i + 2; });
    items.forEach(function (it) {
      if (pos[it.id]) sh.getRange(pos[it.id], 1, 1, 4).setValues([[it.id, it.json, now, it.ws || '']]);
      else add.push([it.id, it.json, now, it.ws || '']);
    });
  }
  if (add.length) sh.getRange(Math.max(2, sh.getLastRow() + 1), 1, add.length, 4).setValues(add);
}

/* ---------- reused helpers ---------- */
/** Header row number found in memory from rows already read (no extra sheet call). */
function headerRowFrom_(all) {
  var cfgRow = cfg_().HEADER_ROW; if (cfgRow && +cfgRow > 0) return +cfgRow;
  for (var i = 0; i < Math.min(15, all.length); i++)
    for (var j = 0; j < all[i].length; j++)
      if (String(all[i][j]).trim().toLowerCase() === 'url') return i + 1;
  return 1;
}

function findCol_(headers, names) {
  for (var i = 0; i < names.length; i++)
    for (var k = 0; k < headers.length; k++)
      if (headers[k] && headers[k].toLowerCase() === names[i]) return headers[k];
  return '';
}

function roles_(h) {
  var H = h.headers;
  var first = ''; for (var i = 0; i < H.length; i++) { if (H[i] && H[i] !== SYS.ID) { first = H[i]; break; } }
  return {
    title: findCol_(H, ['title', 'name', 'document']) || first,
    url: findCol_(H, ['url', 'link']), project: findCol_(H, ['project']),
    l1: findCol_(H, ['l_1', 'l1']), l2: findCol_(H, ['l_2', 'l2']), l3: findCol_(H, ['l_3', 'l3']),
    revisit: findCol_(H, ['revisit']), latest: findCol_(H, ['latest visit']),
    window: findCol_(H, ['revisit window (days)', 'revisit window']), next: findCol_(H, ['next visit']),
    note: findCol_(H, ['note', 'notes']),
    id: findCol_(H, [SYS.ID.toLowerCase()]), type: findCol_(H, [SYS.TYPE.toLowerCase()]),
    added: findCol_(H, [SYS.ADDED.toLowerCase()]), mod: findCol_(H, [SYS.MOD.toLowerCase()]),
    by: findCol_(H, [SYS.BY.toLowerCase()]), status: findCol_(H, [SYS.STATUS.toLowerCase()]),
    addedBy: findCol_(H, [SYS.ADDED_BY.toLowerCase()])
  };
}

/** Best guess of a column's type from its header, used only while the column has no data yet. */
function nameHint_(name) {
  var n = String(name).toLowerCase();
  if (/\bby\b/.test(n)) return 'text';                                                  // Modified By, Added By
  if (/\(days\)|\bwindow\b|\bdays\b|\bqty\b|quantity|amount|\bcount\b/.test(n)) return 'number';   // Revisit Window (days)
  if (/date|latest visit|next visit|last visit|modified|added|created|\bdue\b/.test(n)) return 'date';
  return 'text';                                                                          // includes Revisit, Status, Note
}

function inferType_(name, vs) {
  var hint = nameHint_(name) === 'date';
  if (!vs.length) return nameHint_(name);
  var dates = vs.filter(function (v) { return v instanceof Date; }).length;
  if (dates / vs.length >= 0.6 || (hint && dates > 0)) return 'date';
  if (vs.every(function (v) { return typeof v === 'number'; })) return 'number';
  if (vs.every(function (v) { return /^https?:\/\//i.test(String(v)); })) return 'url';
  if (vs.every(function (v) { return typeof v === 'boolean' || /^(y|n|yes|no|true|false)$/i.test(String(v)); })) return 'flag';
  return 'text';
}

function rowHash_(r, sc) {
  var arr = [];
  for (var i = 0; i < sc.cols.length; i++) { var col = sc.cols[i]; if (!col.formula) arr.push(String(fromCell_(r[col.index]))); }
  return hash53_(JSON.stringify(arr));
}

function hasContent_(r, sc) {
  var t = sc.titleIdx >= 0 ? r[sc.titleIdx] : '', u = sc.urlIdx >= 0 ? r[sc.urlIdx] : '';
  return (t !== '' && t !== null) || (u !== '' && u !== null);
}

function accessDirty_() { _acc = null; try { CacheService.getScriptCache().remove('acc'); } catch (e) {} }

function appUrl_() { try { return ScriptApp.getService().getUrl(); } catch (e) { return ''; } }

/** Text-safe cell for the browser. Sheets turns text like 2026-10-01 into real dates, and Date objects
 *  can't be returned to the web page (the whole call fails), so every cell is converted to a string. */
function logCell_(v, withTime) {
  if (v instanceof Date) return isNaN(v.getTime()) ? '' : (withTime ? stamp_(v) : iso_(v));
  return (v === null || v === undefined) ? '' : String(v);
}

function colByName_(sc, name) { var f = sc.cols.filter(function (c) { return c.name === name; }); return f.length ? f[0] : null; }

/** Columns whose formula only makes sense once a row has a Latest Visit and a Revisit Window. */
function schedCols_(sc) {
  return sc.cols.filter(function (c) { return c.formula && (c.name === sc.roles.next || /weekday/i.test(c.name)); });
}

function isSched_(sc, latest, win) {
  var rl = sc.roles; if (!rl.latest || !rl.window) return false;
  return latest !== '' && latest !== null && latest !== undefined && win !== '' && win !== null && win !== undefined && Number(win) > 0;
}

/** Row number (1-based) of the last data row that has a formula in the given column, or 0. */
function formulaTemplateRow_(h, colIndex) {
  for (var q = h.forms.length - 1; q >= 0; q--) if (h.forms[q][colIndex]) return h.hr + 1 + q;
  return 0;
}

/** Writes the Next Visit / Weekday formula into rows that have a schedule but no formula and no value. */
function fixMissingFormulas_(h, sc, targets) {
  var cols = schedCols_(sc), n = 0;
  cols.forEach(function (c) {
    var tmpl = formulaTemplateRow_(h, c.index), hasCfg = !!formulaFor_(sc, h, c, 1);
    if (!tmpl && !hasCfg) return;
    targets.forEach(function (t) {
      var up = t.updates || {};
      var cur = h.forms[t.k][c.index], val = up.hasOwnProperty(c.index) ? up[c.index] : h.vals[t.k][c.index];
      if (cur || (val !== '' && val !== null)) return;
      var li = sc.roles.latest ? h.headers.indexOf(sc.roles.latest) : -1, wi = sc.roles.window ? h.headers.indexOf(sc.roles.window) : -1;
      var lv = li >= 0 ? (up.hasOwnProperty(li) ? up[li] : h.vals[t.k][li]) : '', wv = wi >= 0 ? (up.hasOwnProperty(wi) ? up[wi] : h.vals[t.k][wi]) : '';
      if (!isSched_(sc, lv, wv)) return;
      var rowNum = h.hr + 1 + t.k;
      if (hasCfg) h.sheet.getRange(rowNum, c.index + 1).setFormula(formulaFor_(sc, h, c, rowNum));
      else h.sheet.getRange(tmpl, c.index + 1).copyTo(h.sheet.getRange(rowNum, c.index + 1));
      n++;
    });
  });
  return n;
}

/** Writes the changed cells of one row in a single call (unchanged cells in the span keep their formulas/values). */
function writeSpan_(h, k, updates) {
  var idxs = Object.keys(updates).map(Number); if (!idxs.length) return;
  var lo = Math.min.apply(null, idxs), hi = Math.max.apply(null, idxs), arr = [];
  for (var c = lo; c <= hi; c++) {
    if (updates.hasOwnProperty(c)) arr.push(updates[c]);
    else arr.push(h.forms[k][c] ? h.forms[k][c] : h.vals[k][c]);
  }
  h.sheet.getRange(h.hr + 1 + k, lo + 1, 1, hi - lo + 1).setValues([arr]);
}

function snapObj_(sc, r) { var o = {}; sc.cols.forEach(function (c) { o[c.name] = fromCell_(r[c.index]); }); return o; }

function shadowRemove_(id) {
  var sh = ss_().getSheetByName(TAB.SHADOW); if (!sh) return;
  var n = sh.getLastRow() - 1; if (n < 1) return;
  var f = sh.getRange(2, 1, n, 1).createTextFinder(String(id)).matchEntireCell(true).findNext();
  if (f) sh.deleteRow(f.getRow());
}

function visits_() {
  var cache = CacheService.getScriptCache();
  try { var hit = cache.get('visits'); if (hit) return JSON.parse(hit); } catch (e) {}
  var out = [];
  try {
    var s = sh_(TAB.LOG), lr = s.getLastRow();
    if (lr >= 2) {
      var start = Math.max(2, lr - 2000), vals = s.getRange(start, 1, lr - start + 1, 5).getValues();
      var cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 100);
      vals.forEach(function (r) { if (r[3] === 'VISIT' && r[0] instanceof Date && r[0] >= cutoff) out.push({ id: String(r[4]), date: iso_(r[0]) }); });
    }
  } catch (e) {}
  try { cache.put('visits', JSON.stringify(out), 120); } catch (e) {}
  return out;
}

function insertRow_(h, sc, v, u, opts) {
  opts = opts || {};
  var rl = sc.roles, today = today_(), row = [];
  var id = opts.id || fmtId_(allocIds_(1));
  for (var i = 0; i < h.lc; i++) row.push('');
  sc.cols.forEach(function (c) {
    if (c.formula) return;
    var val = (c.name in v) ? toCell_(c.type, v[c.name]) : '';
    if (c.name === SYS.ID) val = id;
    else if (c.name === SYS.TYPE) val = detectType_(rl.url ? v[rl.url] : '');
    else if (c.name === SYS.ADDED) val = val || today;
    else if (c.name === SYS.MOD) val = (opts.keepMod && val) ? val : (val || today);
    else if (c.name === SYS.BY) val = u.email;
    else if (c.name === SYS.ADDED_BY) val = (opts.keepAddedBy && val) ? val : u.email;
    else if (c.name === SYS.STATUS) val = val || 'Active';
    row[c.index] = val;
  });
  var last = h.hr;
  for (var k = h.vals.length - 1; k >= 0; k--) if (hasContent_(h.vals[k], sc)) { last = h.hr + 1 + k; break; }
  var newRow = last + 1;
  if (newRow > h.sheet.getMaxRows()) h.sheet.insertRowsAfter(h.sheet.getMaxRows(), 1);
  var nr = h.sheet.getRange(newRow, 1, 1, h.lc);
  if (last > h.hr) {
    h.sheet.getRange(last, 1, 1, h.lc).copyTo(nr);
    var sched = isSched_(sc, rl.latest ? v[rl.latest] : '', rl.window ? v[rl.window] : '');
    var sc_ = schedCols_(sc), isSchedCol = {};
    sc_.forEach(function (c) { isSchedCol[c.index] = true; });
    var lastForms = h.forms[last - h.hr - 1] || [];
    sc.cols.forEach(function (c) {
      if (!c.formula || lastForms[c.index]) return;           // not a formula column, or the copy above already brought it
      if (isSchedCol[c.index] && !sched) return;               // schedule formulas only for rows with a schedule
      var t = formulaTemplateRow_(h, c.index);                 // nearest row that has this column's formula
      if (t) h.sheet.getRange(t, c.index + 1).copyTo(h.sheet.getRange(newRow, c.index + 1));
    });
    var f = nr.getFormulas()[0];
    row = row.map(function (x, i) {
      var col = sc.cols.filter(function (cc) { return cc.index === i; })[0];
      if (col && isSchedCol[i] && !sched) return '';
      return f[i] ? f[i] : x;
    });
  }
  sc.cols.forEach(function (c) { if (!c.formula) return; var ft = formulaFor_(sc, h, c, newRow); if (ft) row[c.index] = ft; });
  nr.setValues([row]);
  return { id: id, row: newRow };
}

/**
 * Audit trail reader (owner and admin). Modes:
 *  latest: the newest opts.n entries (default 10)
 *  window: entries older than the cursor, going back opts.days further
 *  range:  every entry between opts.from and opts.to (YYYY-MM-DD), newest first, max 500
 */
function getLog(opts) {
  guard_('admin');
  opts = opts || {};
  var s = sh_(TAB.LOG), lr = s.getLastRow(), mode = opts.mode || 'latest', DAY = 86400000;
  if (lr < 2) return { rows: [], cursor: null, older: false, total: 0, mode: mode };
  var n = lr - 1;
  var ts = s.getRange(2, 1, n, 1).getValues().map(function (r) {
    var t = r[0] instanceof Date ? r[0].getTime() : new Date(r[0]).getTime();
    return isNaN(t) ? 0 : t;
  });
  var sel = [], cursor = null, truncated = false, i;
  if (mode === 'window') {
    var cRow = Number(opts.cursorRow), lowerTs = Number(opts.cursorTs) - Math.max(1, Number(opts.days) || 1) * DAY;
    for (i = n - 1; i >= 0; i--) if (i + 2 < cRow && ts[i] >= lowerTs) sel.push(i + 2);
    cursor = { row: sel.length ? sel[sel.length - 1] : cRow, ts: lowerTs };
  } else if (mode === 'range') {
    var f = parseDate_(opts.from), t2 = parseDate_(opts.to || opts.from);
    if (!f) throw new Error('Choose a start date.');
    var fromTs = new Date(f.getFullYear(), f.getMonth(), f.getDate(), 0, 0, 0).getTime();
    var toTs = new Date(t2.getFullYear(), t2.getMonth(), t2.getDate(), 23, 59, 59, 999).getTime();
    if (toTs < fromTs) throw new Error('The end date is before the start date.');
    for (i = n - 1; i >= 0; i--) {
      if (ts[i] >= fromTs && ts[i] <= toTs) { if (sel.length >= 500) { truncated = true; break; } sel.push(i + 2); }
    }
  } else {
    var cnt = Math.min(Math.max(Number(opts.n) || 10, 1), 200);
    for (i = n - 1; i >= 0 && sel.length < cnt; i--) sel.push(i + 2);
    var oldest = sel[sel.length - 1];
    cursor = { row: oldest, ts: ts[oldest - 2] };
  }
  var rows = [];
  if (sel.length) {
    var minRow = sel[sel.length - 1], maxRow = sel[0];
    var block = s.getRange(minRow, 1, maxRow - minRow + 1, 12).getValues();
    sel.forEach(function (rw) {
      var r = block[rw - minRow];
      rows.push({ row: rw, t: logCell_(r[0], true), user: logCell_(r[1]), role: logCell_(r[2]), action: logCell_(r[3]),
                  id: logCell_(r[4]), title: logCell_(r[5]), field: logCell_(r[6]), old: logCell_(r[7]), neu: logCell_(r[8]),
                  source: logCell_(r[9]), details: logCell_(r[10]), ws: logCell_(r[11]) });
    });
  }
  return { rows: rows, cursor: cursor, older: cursor ? cursor.row > 2 : false, total: n, mode: mode, truncated: truncated };
}
