# Mercury Document Hub v2.5.0

A Google Apps Script web app over one Google Sheet, with one tab per workstream.
Source sheet: `1egbINWnEhgR5COU88FKDeFTfzmJDGLLUOOCWcVdTHVw` (the ID ends `WcVdTHVw`).

## Files
- `Code.gs`, `Setup.gs`, `Spec.gs`, `Index.html`, `appsscript.json`

## Install (about 5 minutes)
1. Open the Hub sheet, then **Extensions > Apps Script**. Check the project is the one you expect.
2. Replace **every** file with the ones in this package: `Code.gs`, `Setup.gs`, `Spec.gs`, `Index.html`, and `appsscript.json` (turn on **Project Settings > Show "appsscript.json"** to edit it). Do not mix in files from the Gabby-Sunlong package.
3. In `Code.gs`, line 7 must read `var SS_ID = '1egbINWnEhgR5COU88FKDeFTfzmJDGLLUOOCWcVdTHVw';`.
4. Reload the sheet. The menu now reads **Mercury Document Hub**. Choose **Fresh start**, approve the permissions, and choose **Yes**. This clears the copied Mercury data, builds the Access, Log, Archive and Team tabs, and installs the sync triggers. Your workstream tabs and HOME are not touched.
5. **Deploy > Manage deployments > pencil icon > Version: New version > Deploy**. Execute as **Me**, access **Anyone within purestorage.com**. Keep the sheet's own sharing **Restricted**.
6. Open the web app. As owner, open **Governance** and read the **Connection** card: sheet ID ending `WcVdTHVw`, code version `2.5.0`, `8 workstream tabs and the shared area`, and `0 documents`.

## Upgrading from an earlier 2.x version
Replace `Code.gs`, `Setup.gs`, `Spec.gs` and `Index.html` (the manifest is unchanged), then **Mercury Document Hub > Sync project spec**, then **Deploy > Manage deployments > pencil > New version > Deploy**. No need to run Fresh start again, and nothing in your sheet changes.

## Shared documents (All Workstream Assignment)
Documents that apply to several workstreams live once in the **All Workstream Assignment** tab instead of being copied into each workstream. The Assigned To column says who gets it: `All` (or blank), or workstream names separated by semicolons, for example `CTO; MDM`. Each workstream page shows its shared documents in a strip at the top.
- **Who can change them:** owners, admins, and editors you grant the shared area in Governance (it has its own column in the access matrix).
- **Cleaning up copies:** Governance > Data quality offers **Merge into shared** for the same link kept in several workstreams, and **Move to shared** for documents marked `All Workstream`.
- **Setup** creates the tab if it is missing. Type `off` for `SHARED_TAB` in Config to turn the feature off.

## Adding a document from its link
In the Add form the link comes first. Paste a Google Docs, Sheets, Slides, Forms or Drive link and the app fills the Title, the Note (from the file's Drive description) and the categories it can work out, then tells you what it filled. It never overwrites what you typed and never stops you saving.
- **Privacy:** details are filled only when the file's sharing list shows you could open it yourself (named on the file, shared with your domain, shared with anyone, or owner). Otherwise you see one standard message, the same for private, hidden and missing files. Groups are not resolved, so a file shared only with a group is not filled.
- **Categories:** from what earlier documents in the same Drive folder were filed under (learned each time you add a document from a link), then from a folder name that matches a category value already in use, then the usual Project for the workstream. Drive folder names are never copied in as new categories. The learned folders live in the hidden `_Folders` tab.
- **Permissions:** nothing new to approve; the app already has Drive access. If you enable the **Drive API** advanced service (Services > Add a service), sharing is read more exactly (for example a share with another domain); without it the built-in DriveApp is used.
- Only Google links are read. Other links (SharePoint, Confluence, websites) are typed by hand.

## Duplicate links
A link counts as a duplicate only when it is used twice inside the same workstream. The same link in two workstreams is fine.

## How the speed-ups behave
- After someone saves, the next person to open the app rebuilds the data once; everyone after that is served from the shared cache until the next change.
- Changes made in the sheet by hand show up within seconds. Changes made by a script or import (which do not fire the sheet's edit trigger) show up within 3 minutes, or immediately when someone presses **Refresh**.
- Governance > Connection shows how the last load was served and how long it took.

## After install
- **Team tab**: filled from the program structure chart. Edit the Name column (several names separated by a semicolon). Rows with no name stay hidden from viewers. TBH and TBD show muted as open positions.
- **HOME tab**: a designed page. Column A is the text (select words and press Ctrl+B for bold, or insert a link, as in any document), column B the Style (pick from the list: Title, Heading, Text, Bullet, Note, Link, Spacer, Accent), column C an optional web link. Add a row, pick its Style, and it is formatted for you. **Mercury Document Hub > Restyle HOME page** re-applies the design to every row.
- **People**: Governance > Add a person. Editors get a list of workstreams they may edit. Admins and owners edit everywhere.
- **New workstream**: add a tab with the same headers (Title, URL, ... in row 3), then **Mercury Document Hub > Refresh workstream list**.

## Roles
Viewer reads everything. Editor edits only the workstreams listed for them. Admin does everything an editor can do in every workstream, plus access, restore, repairs and the Log. Owner adds granting admin and owner and changing the sheet structure.

## Config keys
`APP_TITLE`, `PROGRAM_NAME`, `POLL_SECONDS`, `HEADER_ROW`, `HIDDEN_COLUMNS`, `GROUP_A`, `GROUP_B`, `SHELF_BY`, `PAGE_SIZE`, `SOON_DAYS`, `SHELF_ORDER`, `AUTO_VIEWER`, `WORKSTREAMS`, `SHARED_TAB`, `SHARED_HINT`, `NEXT_VISIT_FORMULA`, `WEEKDAY_FORMULA`
