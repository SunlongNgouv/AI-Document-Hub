/**
 * Document Hub - Setup.gs (v2: one tab per workstream)
 * Run setupAll() once (menu: Document Hub > Run setup). Safe to re-run.
 * If this sheet was copied from another project, use Document Hub > Fresh start instead; it clears the copied data first.
 * It backs up the file, adds the new columns and tabs, installs the sync triggers
 * and writes the Project_Spec tab. Workstream tabs are found automatically (any tab with Title and URL headers).
 */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Document Hub')
    .addItem('Run setup', 'setupAll')
    .addItem('Fresh start (clear copied data)', 'freshStart')
    .addItem('Refresh workstream list', 'menuRefreshWorkstreams')
    .addItem('Restyle HOME page', 'menuRestyleHome')
    .addItem('Repair Next Visit formulas', 'menuRepairFormulas')
    .addItem('Apply new app name', 'applyAppName')
    .addItem('Sync project spec', 'syncSpec')
    .addItem('Sync sheet sharing with Access tab', 'menuSyncPermissions')
    .addItem('Show web app link', 'menuShowLink')
    .addToUi();
}
function menuSyncPermissions() { syncPermissions_(); SpreadsheetApp.getUi().alert('Sheet sharing now matches the Access tab.'); }
function menuRefreshWorkstreams() {
  wsDirty_(); contentDirty_(); bump_();
  var n = wsNames_();
  SpreadsheetApp.getUi().alert(n.length ? 'The app now shows ' + n.length + ' workstreams:\n' + n.join('\n') : 'No workstream tabs found. A workstream tab needs Title and URL headers in its first rows.');
}
function menuRepairFormulas() {
  var n = withLock_(function () { return repairNextVisits_(); });
  if (n) logEvent_({ user: me_() || Session.getEffectiveUser().getEmail(), role: 'owner', action: 'REPAIR', source: 'Sheet', title: 'Next Visit formulas', details: 'Wrote the Next Visit formula into ' + n + ' cell(s).' });
  SpreadsheetApp.getUi().alert(n ? 'Repaired ' + n + ' cell(s).' : 'Nothing to repair. Every row with a schedule already has a Next Visit formula.');
}
/** Menu: moves the Config APP_TITLE from an old default name to this version's name. A custom title is left alone. */
function applyAppName() {
  var s = sh_(TAB.CONFIG), newName = CFG_DEFAULTS.APP_TITLE, done = false;
  var n = s.getLastRow() - 1, rows = n > 0 ? s.getRange(2, 1, n, 2).getValues() : [];
  for (var i = 0; i < rows.length; i++) {
    if (String(rows[i][0]).trim() === 'APP_TITLE') {
      var cur = String(rows[i][1]).trim();
      if (cur !== newName && (cur === '' || OLD_APP_NAMES.indexOf(cur) >= 0)) { s.getRange(i + 2, 2).setValue(newName); done = true; }
      break;
    }
  }
  cfgDirty_(); syncSpec(); bump_();
  var msg = done ? 'The app is now called "' + newName + '".' : 'The Config tab already has the current or a custom app name, so it was left as is.';
  try { SpreadsheetApp.getUi().alert(msg); } catch (e) {}
  return done;
}
function menuShowLink() {
  var u = appUrl_();
  SpreadsheetApp.getUi().alert(u ? 'Web app link:\n' + u : 'Deploy the web app first (Deploy > New deployment > Web app).');
}

function ensureTab_(name, headers) {
  var book = ss_(), s = book.getSheetByName(name);
  if (!s) s = book.insertSheet(name);
  if (s.getLastRow() === 0 && headers && headers.length) {
    s.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold').setBackground('#F2CDC4').setFontColor('#2D2A27');
    s.setFrozenRows(1);
  }
  return s;
}
/** Adds any header that is still missing (new columns introduced by a newer version). Existing headers are never changed. */
function ensureHeaders_(s, headers) {
  var cur = s.getLastColumn() ? s.getRange(1, 1, 1, Math.max(s.getLastColumn(), headers.length)).getValues()[0] : [];
  headers.forEach(function (h, i) {
    if (String(cur[i] || '').trim() === '') s.getRange(1, i + 1).setValue(h).setFontWeight('bold').setBackground('#F2CDC4').setFontColor('#2D2A27');
  });
}

function seedConfig_(s) {
  var existing = {};
  if (s.getLastRow() > 1) s.getRange(2, 1, s.getLastRow() - 1, 1).getValues().forEach(function (r) { existing[String(r[0]).trim()] = 1; });
  var notes = {
    APP_TITLE: 'Name shown in the app header.',
    POLL_SECONDS: 'How often the app checks the sheet for changes (10 to 120).',
    HEADER_ROW: 'Leave blank to auto-detect the row that contains the URL header.',
    HIDDEN_COLUMNS: 'Comma-separated column names to hide from the app (they stay in the sheet).',
    PROGRAM_NAME: 'Program name shown above "Program structure" on the Home page.',
    GROUP_A: 'Default column for the donut chart on Insights.',
    GROUP_B: 'Default column for the bar chart on Insights.',
    SHELF_BY: 'Default column that groups the shelves on a workstream page.',
    PAGE_SIZE: 'Rows per page in tables.',
    SOON_DAYS: 'A document counts as "Due soon" when its Next Visit is within this many days.',
    AUTO_VIEWER: 'Type on to give every signed-in company account viewer access automatically. Leave blank so an owner or admin approves each person. Editor, admin and owner always need approval.',
    NEXT_VISIT_FORMULA: 'Formula (without the leading =) written into Next Visit for new rows. {row}, {latest}, {window} stand for the row and column letters.',
    WEEKDAY_FORMULA: 'Formula (without the leading =) written into Weekday for new rows. {next} stands for the Next Visit column letter.',
    SHELF_ORDER: 'Comma-separated shelf names that always appear first on a workstream page, in this order. Other shelves follow by size.',
    WORKSTREAMS: 'Leave blank to use every tab that has Title and URL headers, in tab order. Or list tab names, comma-separated, to choose which tabs are workstreams and in what order (include the shared tab if you list names).',
    SHARED_TAB: 'Name of the shared area tab: documents stored once and assigned to all or some workstreams (column Assigned To). Created by setup if missing. Type off to turn the shared area off.',
    SHARED_HINT: 'Governance suggests moving a document into the shared area when one of its category values equals this text (for example L_2 = All Workstream).'
  };
  var add = [];
  Object.keys(CFG_DEFAULTS).forEach(function (k) { if (!existing[k]) add.push([k, CFG_DEFAULTS[k], notes[k] || '']); });
  if (add.length) s.getRange(s.getLastRow() + 1, 1, add.length, 3).setValues(add);
  cfgDirty_();
}

/** First row that has a URL header (the header row of a workstream tab). */
function headerRow_(sheet) {
  var c = cfg_().HEADER_ROW; if (c && +c > 0) return +c;
  var rows = sheet.getRange(1, 1, Math.min(15, Math.max(1, sheet.getLastRow())), Math.max(1, sheet.getLastColumn())).getValues();
  for (var i = 0; i < rows.length; i++)
    for (var j = 0; j < rows[i].length; j++)
      if (String(rows[i][j]).trim().toLowerCase() === 'url') return i + 1;
  return 1;
}
/** Creates the shared area tab (same headers as the workstream tabs, plus Assigned To) when it does not exist yet. */
function ensureSharedTab_() {
  var name = String(cfg_().SHARED_TAB || '').trim(); if (!name || /^(off|none|no)$/i.test(name)) return false;
  var book = ss_(); if (book.getSheetByName(name)) return false;
  var names = wsNames_(); if (!names.length) return false;
  var first = book.getSheetByName(names[0]), hr = headerRow_(first), lc = first.getLastColumn();
  var idx = 0; book.getSheets().forEach(function (sh, i) { if (names.indexOf(sh.getName()) >= 0) idx = i + 1; });
  var s = book.insertSheet(name, idx);
  first.getRange(1, 1, hr, lc).copyTo(s.getRange(1, 1, hr, lc));
  s.getRange(1, 1).setValue(name + ' Document Hub');
  first.getRange(hr, lc).copyTo(s.getRange(hr, lc + 1), { formatOnly: true });
  s.getRange(hr, lc + 1).setValue(ASSIGN);
  for (var c = 1; c <= lc; c++) { try { s.setColumnWidth(c, first.getColumnWidth(c)); } catch (e) {} }
  try { s.setColumnWidth(lc + 1, 230); s.setFrozenRows(hr); s.setFrozenColumns(first.getFrozenColumns()); } catch (e) {}
  wsDirty_(); contentDirty_();
  return true;
}

/** Makes one workstream tab ready: Title and Weekday headers, the system columns, and blank system fields. */
function migrateWs_(name) {
  var sheet = sh_(name), hr = headerRow_(sheet), lc = sheet.getLastColumn();
  var hdr = sheet.getRange(hr, 1, 1, lc).getValues()[0].map(function (x) { return String(x).trim(); });
  if (hdr[0] && hdr[0].toLowerCase() !== 'title' && hdr.map(function (x) { return x.toLowerCase(); }).indexOf('title') < 0) sheet.getRange(hr, 1).setValue('Title');
  var lr = sheet.getLastRow();
  for (var i = 0; i < lc; i++) {
    if (hdr[i]) continue;
    if (lr > hr) {
      var below = sheet.getRange(hr + 1, i + 1, lr - hr, 1).getValues();
      if (below.some(function (r) { return r[0] !== ''; })) sheet.getRange(hr, i + 1).setValue('Weekday');
    }
  }
  hdr = sheet.getRange(hr, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (x) { return String(x).trim(); });
  var lastHdr = 0; hdr.forEach(function (x, i) { if (x) lastHdr = i + 1; });
  var need = [SYS.ID, SYS.TYPE, SYS.ADDED, SYS.MOD, SYS.BY, SYS.STATUS, SYS.ADDED_BY].filter(function (nm) { return hdr.indexOf(nm) < 0; });
  if (need.length) {
    var start = lastHdr + 1;
    if (start + need.length - 1 > sheet.getMaxColumns()) sheet.insertColumnsAfter(sheet.getMaxColumns(), start + need.length - 1 - sheet.getMaxColumns());
    sheet.getRange(hr, lastHdr).copyTo(sheet.getRange(hr, start, 1, need.length), { formatOnly: true });
    sheet.getRange(hr, start, 1, need.length).setValues([need]);
  }
  return fillMissingWs_(name, 'Setup');
}

function installTriggers_() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    var f = t.getHandlerFunction();
    if (f === 'onSheetEdit' || f === 'onSheetChange') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('onSheetEdit').forSpreadsheet(SS_ID).onEdit().create();
  ScriptApp.newTrigger('onSheetChange').forSpreadsheet(SS_ID).onChange().create();
}

function protectAdminTabs_() {
  var me = Session.getEffectiveUser();
  [TAB.ACCESS, TAB.REQ, TAB.LOG, TAB.ARCHIVE, TAB.CONFIG, TAB.SPEC, TAB.SHADOW].forEach(function (n) {
    try {
      var s = ss_().getSheetByName(n); if (!s) return;
      var ps = s.getProtections(SpreadsheetApp.ProtectionType.SHEET), p = ps.length ? ps[0] : s.protect();
      p.setDescription('Managed by Document Hub. Only the owner can edit.');
      p.addEditor(me);
      var others = p.getEditors().filter(function (u) { return u.getEmail() !== me.getEmail(); });
      if (others.length) p.removeEditors(others);
      if (p.canDomainEdit()) p.setDomainEdit(false);
    } catch (e) { console.error('protect ' + n, e); }
  });
}

/** Stops the setup if this script is attached to a different spreadsheet than SS_ID (e.g. old code left in a copied sheet). */
function assertBound_() {
  var active = null; try { active = SpreadsheetApp.getActiveSpreadsheet(); } catch (e) {}
  if (active && active.getId() !== SS_ID)
    throw new Error('This script is attached to a different spreadsheet (' + active.getId() + ') than SS_ID in Code.gs (' + SS_ID + '). Paste the Document Hub files into the Apps Script project of the Document Hub sheet.');
}
function hubHasContent_() {
  return wsNames_().some(function (n) { var h = readWs_(n, false), sc = schema_(h); return h.vals.some(function (r) { return hasContent_(r, sc); }); });
}
/** Spec titles of the projects this one was cloned from. A sheet that still carries one of them is a raw copy. */
var SOURCE_PROJECT_NAMES = ['Gabby-Sunlong Document Central'];
/** True when every workstream tab is empty but the side tabs show this sheet was copied from another project:
 *  the spec tab carries another sheet's ID (or an older source-project title), or the shadow copy still lists documents the tabs no longer have.
 *  Renaming this app never triggers it. */
function staleCopyDetected_() {
  if (hubHasContent_()) return false;
  var sp = ss_().getSheetByName(TAB.SPEC), title = '', mark = '';
  if (sp && sp.getLastRow() >= 1) { title = String(sp.getRange(1, 3).getValue()); mark = String(sp.getRange(1, 5).getValue()); }
  var shadow = ss_().getSheetByName(TAB.SHADOW), shadowRows = shadow ? Math.max(0, shadow.getLastRow() - 1) : 0;
  var foreign = /^Sheet ID: /.test(mark) ? mark !== 'Sheet ID: ' + SS_ID : SOURCE_PROJECT_NAMES.some(function (n) { return title.indexOf(n) === 0; });
  return foreign || shadowRows > 0;
}
var FRESH_MSG = 'This sheet holds data copied from another project. Continue to clear the Access_Requests, Audit_Log, Archive and hidden _Shadow tabs, reset the Config and Project_Spec tabs, and reset the Access tab to ' + OWNER_SEED + ' only. Your workstream tabs, HOME and Team tabs are not touched.';
function wipeCopiedData_() {
  [TAB.REQ, TAB.LOG, TAB.ARCHIVE, TAB.SHADOW].forEach(function (n) {
    var t = ss_().getSheetByName(n);
    if (t && t.getLastRow() > 1) t.getRange(2, 1, t.getLastRow() - 1, Math.max(1, t.getLastColumn())).clearContent();
  });
  [TAB.CONFIG, TAB.ACCESS, TAB.SPEC].forEach(function (n) { var t = ss_().getSheetByName(n); if (t) t.clear(); });
  var keys = ['acc', 'sync', 'visits', 'wsn', 'home', 'team', 'cfg', 'ds:meta'];
  try { wsNames_().forEach(function (n) { keys.push('fc:' + n); }); } catch (e) {}
  PropertiesService.getScriptProperties().deleteAllProperties();
  try { CacheService.getScriptCache().removeAll(keys); } catch (e) {}
  _cfg = null; _acc = null; _wsn = null;
}
/** Menu: clears data copied from another project, then runs the normal setup. */
function freshStart() {
  assertBound_();
  var ui = SpreadsheetApp.getUi();
  if (ui.alert('Fresh start', FRESH_MSG, ui.ButtonSet.YES_NO) !== ui.Button.YES) return;
  wipeCopiedData_();
  setupAll();
}
/** Date formats for the date columns, applied down the whole column so new rows look right. */
function formatWsColumns_() {
  wsNames_().forEach(function (n) {
    var h = readWs_(n, false), sc = schema_(h), rl = sc.roles, rowsBelow = Math.max(1, h.sheet.getMaxRows() - h.hr);
    [rl.latest, rl.next, rl.added, rl.mod].filter(Boolean).forEach(function (nm) {
      var i = h.headers.indexOf(nm); if (i >= 0) h.sheet.getRange(h.hr + 1, i + 1, rowsBelow, 1).setNumberFormat('mm/dd/yyyy');
    });
  });
}

function setupAll() {
  assertBound_();
  wsDirty_();
  if (!wsNames_().length) throw new Error('No workstream tabs found. A workstream tab needs Title and URL headers in its first rows (CTO, MDM and so on).');
  try { if (ensureSharedTab_()) wsDirty_(); } catch (e) { console.error('shared tab', e); }
  if (staleCopyDetected_()) {
    var ui = null; try { ui = SpreadsheetApp.getUi(); } catch (e) {}
    if (!ui) throw new Error('This sheet still holds data copied from another project. Open the sheet and choose Document Hub > Fresh start, which asks before clearing it.');
    if (ui.alert('Clear copied data?', FRESH_MSG, ui.ButtonSet.YES_NO) !== ui.Button.YES) return;
    wipeCopiedData_();
  }
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('BACKUP_DONE')) {
    DriveApp.getFileById(SS_ID).makeCopy(ss_().getName() + ' - backup before Document Hub ' + Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd HHmm'));
    props.setProperty('BACKUP_DONE', '1');
  }
  seedConfig_(ensureTab_(TAB.CONFIG, ['Key', 'Value', 'Notes']));
  var acc = ensureTab_(TAB.ACCESS, ['Email', 'Role', 'Name', 'Granted By', 'Granted On', 'Editor of']);
  ensureHeaders_(acc, ['Email', 'Role', 'Name', 'Granted By', 'Granted On', 'Editor of']);
  if (!accessRows_(true).some(function (r) { return r.email === OWNER_SEED; })) { acc.appendRow([OWNER_SEED, 'owner', '', 'Setup', new Date(), '']); accessDirty_(); }
  var reqHdr = ['Request ID', 'Email', 'Reason', 'Status', 'Requested On', 'Decided By', 'Decided On', 'Granted Role', 'Requested workstreams', 'Granted workstreams'];
  ensureHeaders_(ensureTab_(TAB.REQ, reqHdr), reqHdr);
  var logHdr = ['Timestamp', 'User', 'Role', 'Action', 'Doc ID', 'Title', 'Field', 'Old Value', 'New Value', 'Source', 'Details', 'Workstream'];
  ensureHeaders_(ensureTab_(TAB.LOG, logHdr), logHdr);
  var arcHdr = ['Doc ID', 'Title', 'URL', 'Deleted On', 'Deleted By', 'Reason', 'Snapshot', 'Workstream'];
  ensureHeaders_(ensureTab_(TAB.ARCHIVE, arcHdr), arcHdr);
  ensureTab_(TAB.SPEC, ['Section', 'ID', 'Item', 'Detail', 'Status']);
  var shHdr = ['Doc ID', 'Snapshot', 'Updated', 'Workstream'];
  var shadow = ensureTab_(TAB.SHADOW, shHdr); ensureHeaders_(shadow, shHdr); shadow.hideSheet();
  ensureTab_(TAB.HOME, null);
  var teamHdr = ['Section', 'Workstream', 'Role', 'Org', 'Name', 'Note'];
  var teamSheet = ensureTab_(TAB.TEAM, teamHdr); ensureHeaders_(teamSheet, teamHdr); seedTeam_(teamSheet);
  ss_().getSheetByName(TAB.LOG).getRange('A:A').setNumberFormat('yyyy-mm-dd hh:mm:ss');
  var filled = 0;
  wsNames_().forEach(function (n) { filled += migrateWs_(n); });
  formatWsColumns_();
  try { repairNextVisits_(); } catch (e) { console.error('repair', e); }
  syncSpec();
  refreshShadow_();
  installTriggers_();
  protectAdminTabs_();
  try { syncPermissions_(); } catch (e) {}
  contentDirty_();
  logEvent_({ user: Session.getEffectiveUser().getEmail(), role: 'owner', action: 'SETUP', source: 'Sheet', details: 'Setup complete for ' + wsNames_().length + ' workstreams. Filled ' + filled + ' blank system cells.' });
  bump_();
  try { SpreadsheetApp.getUi().alert('Setup complete for ' + wsNames_().length + ' workstreams. Next: Deploy > New deployment > Web app (Execute as: Me, Access: Anyone within ' + DOMAIN + '). Keep this sheet\'s own sharing set to Restricted.'); } catch (e) {}
}

/* ---------- HOME page design (Content | Style | Link) ---------- */
var HOME_UI = { paper: '#FFFBF2', cloud: '#FFF5E3', ash: '#2D2A27', orange: '#FF7023', rose: '#F2CDC4', cinnamon: '#9E5633', gray: '#8B857C', font: 'Roboto' };
/** Styles one HOME row from its Style value (column B). Safe to run again on any row. */
/** Height for a wrapped row: lines estimated from the text length and the column width (Sheets does not fit rows reliably from a script). */
function homeRowHeight_(kind, text, colWidth) {
  var charPx = kind === 'text' ? 7.6 : 6.8, lineH = kind === 'text' ? 20 : 18, pad = kind === 'text' ? 20 : (kind === 'note' ? 22 : 8);
  var avail = Math.max(120, colWidth - 40 - (kind === 'bullet' ? 22 : 0));
  var lines = Math.max(1, Math.ceil(String(text || '').length * charPx / avail));
  return lines * lineH + pad;
}
function styleHomeRow_(sh, row, kind, text) {
  var U = HOME_UI, all = sh.getRange(row, 1, 1, 3), a = sh.getRange(row, 1), side = sh.getRange(row, 2, 1, 2);
  all.setBackground(U.paper).setFontFamily(U.font).setFontColor(U.ash).setFontSize(11).setFontWeight('normal').setFontStyle('normal')
     .setWrap(true).setVerticalAlignment('top').setBorder(false, false, false, false, false, false);
  a.setNumberFormat('@');
  side.setFontSize(9).setFontColor(U.gray).setBackground(U.cloud).setVerticalAlignment('middle');
  var auto = true;
  if (kind === 'title') {
    all.setBackground(U.ash); a.setFontColor(U.cloud).setFontSize(26).setFontWeight('bold').setVerticalAlignment('middle'); side.setBackground(U.ash);
    sh.setRowHeight(row, 76); auto = false;
  } else if (kind === 'accent') {
    all.setBackground(U.orange); side.setFontColor(U.orange); sh.setRowHeight(row, 6); auto = false;
  } else if (kind === 'spacer') {
    sh.setRowHeight(row, 14); auto = false;
  } else if (kind === 'heading') {
    a.setFontSize(15).setFontWeight('bold').setVerticalAlignment('bottom');
    all.setBorder(null, null, true, null, null, null, U.orange, SpreadsheetApp.BorderStyle.SOLID_MEDIUM);
    sh.setRowHeight(row, 40); auto = false;
  } else if (kind === 'bullet') {
    a.setNumberFormat('"•   "@');
  } else if (kind === 'note') {
    a.setBackground(U.rose).setBorder(null, true, null, null, null, null, U.orange, SpreadsheetApp.BorderStyle.SOLID_THICK);
  } else if (kind === 'link') {
    a.setFontColor(U.cinnamon).setFontWeight('bold');
  } else if (kind === 'text') {
    a.setFontSize(12);
  }
  if (auto) { try { sh.setRowHeight(row, homeRowHeight_(kind, text, sh.getColumnWidth(1))); } catch (e) {} }
}
function styleHome_(sh, r1, r2) {
  r1 = Math.max(1, r1 || 1); r2 = Math.min(r2 || sh.getLastRow(), sh.getMaxRows());
  if (r2 < r1) return 0;
  var vals = sh.getRange(r1, 1, r2 - r1 + 1, 2).getValues();
  for (var i = 0; i < vals.length; i++) styleHomeRow_(sh, r1 + i, String(vals[i][1]).trim().toLowerCase(), vals[i][0]);
  return vals.length;
}
/** Menu: re-applies the page design to every HOME row (use after pasting many rows). */
function menuRestyleHome() {
  var sh = ss_().getSheetByName(TAB.HOME), ui = SpreadsheetApp.getUi();
  if (!sh) { ui.alert('There is no HOME tab.'); return; }
  var n = styleHome_(sh, 1, Math.max(sh.getLastRow(), 1));
  contentDirty_(); bump_();
  ui.alert('Styled ' + n + ' rows of the HOME page. New rows are styled automatically when you pick their Style.');
}

/** The Team tab starts empty in this edition. Add your own rows if you want a Team panel on the pages
 *  (columns: Section, Workstream, Role, Org, Name, Note). */
function seedTeam_(s) { return 0; }
/* ---------- triggers: direct edits in the sheet ---------- */
var ADMIN_ONLY_TABS = ['Access', 'Access_Requests', 'Audit_Log', 'Archive', 'Config', 'Project_Spec'];

function onSheetEdit(e) {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) { try { bump_(); } catch (x) {} return; }
  try {
    var r = e.range, sheet = r.getSheet(), name = sheet.getName();
    var email = String((e.user && e.user.getEmail()) || '').toLowerCase();
    var u = email ? userOf_(email) : { email: '', role: 'unknown', edit: [] }, role = u.role;
    var isWs = wsNames_().indexOf(name) >= 0;
    function revert() { if (e.oldValue !== undefined) r.setValue(e.oldValue); else r.clearContent(); }
    if (!isWs) {
      if (name === TAB.CONFIG) cfgDirty_();
      if (name === TAB.ACCESS) accessDirty_();
      if (name === TAB.HOME || name === TAB.TEAM) {
        contentDirty_();
        if (email && RANK[role] < RANK.admin) {
          revert(); contentDirty_();
          logEvent_({ user: email, role: role, action: 'BLOCKED', source: 'Sheet', title: name, details: 'Only owners and admins can edit this tab. Change reverted.' });
        } else if (name === TAB.HOME) {
          try { styleHome_(sheet, r.getRow(), Math.min(r.getLastRow(), r.getRow() + 40)); } catch (x) { console.error('style home', x); }
        }
        return;
      }
      if (ADMIN_ONLY_TABS.indexOf(name) >= 0 && role !== 'owner' && email) {
        revert();
        if (name === TAB.ACCESS) accessDirty_();
        logEvent_({ user: email, role: role, action: 'BLOCKED', source: 'Sheet', title: name, details: 'Only owners can edit this tab. Change reverted.' });
      }
      return;
    }
    var hr = headerRow_(sheet), single = r.getNumRows() === 1 && r.getNumColumns() === 1;
    var headerEdit = r.getRow() <= hr;
    var blocked = email && (headerEdit ? RANK[role] < RANK.admin : !canEditWs_(u, name));
    if (blocked) {
      if (single) revert();
      logEvent_({ user: email, role: role, action: 'BLOCKED', source: 'Sheet', ws: name, details: (single ? 'Change reverted. ' : 'Multi-cell change could not be reverted. ') + (headerEdit ? 'Only owners and admins can change headers.' : 'You can edit only your own workstreams.') + ' Range ' + r.getA1Notation() });
      return;
    }
    var lc = sheet.getLastColumn(), headers = sheet.getRange(hr, 1, 1, lc).getValues()[0].map(function (x) { return String(x).trim(); });
    if (headerEdit) {
      logEvent_({ user: email, role: role, action: 'SCHEMA_CHANGE', source: 'Sheet', ws: name, details: 'Header edited at ' + r.getA1Notation() + (single ? ': "' + (e.oldValue || '') + '" to "' + (e.value || '') + '"' : '') });
      return;
    }
    var ix = function (nm) { return headers.indexOf(nm); };
    var iId = ix(SYS.ID), iTy = ix(SYS.TYPE), iA = ix(SYS.ADDED), iM = ix(SYS.MOD), iB = ix(SYS.BY), iS = ix(SYS.STATUS), iAB = ix(SYS.ADDED_BY);
    var rl = roles_({ headers: headers }), iT = rl.title ? ix(rl.title) : -1, iU = rl.url ? ix(rl.url) : -1;
    var iL = rl.latest ? ix(rl.latest) : -1, iW = rl.window ? ix(rl.window) : -1;
    var c1 = r.getColumn() - 1, c2 = r.getLastColumn() - 1, today = today_(), by = email || 'unknown';
    var stampCols = [iId, iTy, iA, iM, iB, iAB].filter(function (i) { return i >= 0; });
    var touchesOnlyStamps = true;
    for (var cc = c1; cc <= c2; cc++) if (stampCols.indexOf(cc) < 0) { touchesOnlyStamps = false; break; }
    var manualMod = iM >= 0 && iM >= c1 && iM <= c2;
    var rowStart = r.getRow(), rowEnd = Math.min(r.getLastRow(), rowStart + 399), nRows = rowEnd - rowStart + 1;
    // One read for the whole edited block, one write per changed stamp column (instead of several calls per row).
    var block = sheet.getRange(rowStart, 1, nRows, lc).getValues();
    var changedCols = {}, logs = [], touched = [], needIds = 0, nextId = null;
    function put(row, i, val) { if (i >= 0) { block[row][i] = val; changedCols[i] = true; } }
    for (var q0 = 0; q0 < nRows; q0++) {
      var v0 = block[q0], c0 = (iT >= 0 && v0[iT] !== '') || (iU >= 0 && v0[iU] !== '');
      if (c0 && iId >= 0 && (v0[iId] === '' || v0[iId] === null)) needIds++;
    }
    if (needIds) nextId = allocIds_(needIds);
    for (var k = 0; k < nRows; k++) {
      var vals = block[k];
      var content = (iT >= 0 && vals[iT] !== '') || (iU >= 0 && vals[iU] !== '');
      if (!content) continue;
      var isNew = iId >= 0 && (vals[iId] === '' || vals[iId] === null);
      if (isNew) {
        var id = fmtId_(nextId++);
        put(k, iId, id);
        if (iA >= 0 && !vals[iA]) put(k, iA, today);
        if (iM >= 0 && !vals[iM]) put(k, iM, today);
        if (iS >= 0 && !vals[iS]) put(k, iS, 'Active');
        put(k, iB, by);
        if (iAB >= 0 && !vals[iAB]) put(k, iAB, by);
        if (iTy >= 0 && iU >= 0) put(k, iTy, detectType_(vals[iU]));
        logs.push({ user: email, role: role, action: 'CREATE', source: 'Sheet', ws: name, id: id, title: vals[iT >= 0 ? iT : 0], details: 'Row added directly in the sheet' });
        touched.push(k); continue;
      }
      if (touchesOnlyStamps) continue;
      if (iM >= 0 && !manualMod) put(k, iM, today);
      put(k, iB, by);
      if (iTy >= 0 && iU >= 0 && iU >= c1 && iU <= c2) put(k, iTy, detectType_(vals[iU]));
      var id2 = iId >= 0 ? vals[iId] : '';
      if (single) logs.push({ user: email, role: role, action: 'UPDATE', source: 'Sheet', ws: name, id: id2, title: iT >= 0 ? vals[iT] : '', field: headers[c1], old: e.oldValue === undefined ? '' : e.oldValue, neu: e.value === undefined ? '' : e.value });
      else logs.push({ user: email, role: role, action: 'UPDATE', source: 'Sheet', ws: name, id: id2, title: iT >= 0 ? vals[iT] : '', details: 'Multi-cell edit in ' + r.getA1Notation() });
      touched.push(k);
    }
    Object.keys(changedCols).forEach(function (ci) {
      ci = +ci;
      sheet.getRange(rowStart, ci + 1, nRows, 1).setValues(block.map(function (row) { return [row[ci]]; }));
    });
    if (iL >= 0 && iW >= 0 && touched.length) {
      var schedCheck = { roles: { latest: rl.latest, window: rl.window } };
      [rl.next, headers.filter(function (x) { return /weekday/i.test(x); })[0]].filter(Boolean).forEach(function (nm) {
        var ci = headers.indexOf(nm), key = nm === rl.next ? 'NEXT_VISIT_FORMULA' : 'WEEKDAY_FORMULA';
        if (ci < 0 || !String(cfg_()[key] || '').trim()) return;
        var fs = sheet.getRange(rowStart, ci + 1, nRows, 1).getFormulas(), out = [], any = false;
        for (var q = 0; q < nRows; q++) {
          var cur = block[q][ci], f = fs[q][0];
          if (!f && (cur === '' || cur === null) && touched.indexOf(q) >= 0 && isSched_(schedCheck, block[q][iL], block[q][iW])) { out.push([formulaText_(key, headers, rl, rowStart + q)]); any = true; }
          else out.push([f || cur]);
        }
        if (any) sheet.getRange(rowStart, ci + 1, nRows, 1).setValues(out);
      });
    }
    // Track duplicate links (within this workstream) created by typing or pasting directly in the sheet.
    if (iU >= 0 && iU >= c1 && iU <= c2 && touched.length) {
      var wh = readWs_(name, false), wsc = schema_(wh);
      touched.forEach(function (k) {
        var others = dupInWs_(wh, wsc, block[k][iU], block[k][iId]);
        if (others.length) logs.push(dupLog_({ email: email, role: role }, String(block[k][iId] || ''), iT >= 0 ? block[k][iT] : '', headers[iU], block[k][iU], others, name));
      });
    }
    logBatch_(logs);
    if (iId >= 0 && touched.length) {
      shadowUpsert_(touched.filter(function (k) { return block[k][iId]; }).map(function (k) {
        var o = {}; headers.forEach(function (hname, i) { if (hname) o[hname] = fromCell_(block[k][i]); });
        return { id: String(block[k][iId]), ws: name, json: JSON.stringify(o) };
      }));
    }
  } catch (err) { console.error('onSheetEdit', err); }
  finally { try { bump_(); } catch (x) {} lock.releaseLock(); }
}

/** Structural changes only. A document that exists in some workstream tab is never archived, so cutting a row from one tab and pasting it into another is safe. */
function onSheetChange(e) {
  var t = e && e.changeType; if (t === 'FORMAT') return;
  var email = String((e && e.user && e.user.getEmail()) || '').toLowerCase();
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(25000)) return;
  try {
    if (t === 'INSERT_GRID' || t === 'REMOVE_GRID') { wsDirty_(); contentDirty_(); }
    if (t === 'INSERT_COLUMN' || t === 'REMOVE_COLUMN')
      logEvent_({ user: email, role: email ? roleOf_(email) : '', action: 'SCHEMA_CHANGE', source: 'Sheet', details: t + '. The web app picks up the new columns automatically.' });
    if (['REMOVE_ROW', 'REMOVE_GRID', 'INSERT_GRID', 'OTHER'].indexOf(t) < 0) return;
    var cur = {};
    wsNames_().forEach(function (n) {
      var h = readWs_(n, false), idN = h.headers.indexOf(SYS.ID); if (idN < 0) return;
      h.vals.forEach(function (r) { if (r[idN]) cur[String(r[idN])] = n; });
    });
    var sh = ss_().getSheetByName(TAB.SHADOW);
    if (sh && sh.getLastRow() > 1) {
      var arch = sh_(TAB.ARCHIVE), archived = {};
      if (arch.getLastRow() > 1) arch.getRange(2, 1, arch.getLastRow() - 1, 1).getValues().forEach(function (r) { archived[String(r[0])] = 1; });
      sh.getRange(2, 1, sh.getLastRow() - 1, 4).getValues().forEach(function (s) {
        var id = String(s[0]);
        if (!id || cur[id] || archived[id]) return;
        var o = {}; try { o = JSON.parse(s[1]); } catch (x) {}
        var title = o.Title || o.Name || '', url = o.URL || o.Link || '', ws = String(s[3] || o.Workstream || '');
        arch.appendRow([id, title, url, new Date(), email || 'unknown', 'Row removed directly in the sheet', s[1], ws]);
        logEvent_({ user: email, role: email ? roleOf_(email) : '', action: 'DELETE', source: 'Sheet', ws: ws, id: id, title: title, details: 'Row removed in the sheet and moved to Archive' });
      });
    }
    refreshShadow_();
  } catch (err) { console.error('onSheetChange', err); }
  finally { try { bump_(); } catch (x) {} lock.releaseLock(); }
}
